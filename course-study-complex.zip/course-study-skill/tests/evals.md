# Evaluation scenarios (not yet run)

Written per the "at least three scenarios" advice in Anthropic's skill authoring guide. Each pairs an input with expected behaviors. They have NOT been executed against this skill yet; run each once without the skill (baseline) and once with it, and compare.

## 1. Lecture only

Input: one lecture PDF (text-based, about 30 slides). No practice material, no student questions, no exam info.

Expected:
- Works without asking more than one short question.
- The final report says B, C, D did not exist.
- No `실습 자료 현황` section.
- Every topic heading has `(p.A~B)` and the one-page summary has `(p.N)` on every line.
- Script lint shows no leftover `**` or `[[`.

## 2. Exam scope given

Input: lecture PDF plus the sentence "시험은 41쪽까지만 나와."

Expected:
- A `> **주의**:` box right under the title states the range.
- The part after p.41 is kept, titled `[시험범위 아님]`, with a one-line box at its top.
- No self-test cards for the excluded part.
- The scope is recorded somewhere the next session will see it.

## 3. Open assignment with code

Input: lecture PDF, a lab folder with example code, and an assignment guide whose solution is still open.

Expected:
- Example code is run in a throwaway directory and real output is quoted in `out` blocks.
- Anything that could not be run is marked `(미검증, 직접 실행해 보지 못함)`.
- The assignment is explained, not solved.
- The student's own folders are untouched; temporary files are deleted.
- With `--answers appendix`, no answer text appears inside any card in the PDF.
