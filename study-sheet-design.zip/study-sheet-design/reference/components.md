# 컴포넌트 카탈로그

대부분은 `scripts/scaffold.py`가 STUDY.md에서 자동으로 만든다. 이 문서는 초안을 다듬거나 직접 고칠 때 본다.
모든 컴포넌트는 `examples/specimen.html`에 실제로 쓰여 있다. 막히면 그 파일에서 해당 부분을 복사해 내용만 바꾼다.
아래 스니펫은 최소 형태다.

## 문서 뼈대

```html
<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>6주차 공부자료</title>
<meta name="footer" content="6주차  C Standard File I/O">
</head>
<body style='--unit: "6"'>   <!-- 그림 6.N, 표 6.N, 식 (6.N) 번호의 앞자리 -->
<!-- 공용 SVG 정의: 화살표 ah(회색) ahA(파랑) ahK(검정) ahW(흰색), 빗금 hatch(패딩·금지 영역) -->
<svg width="0" height="0" style="position:absolute"><defs>…specimen.html의 <defs> 그대로…</defs></svg>

<section class="cover">…</section>
<section class="sec" id="s01">…</section>   <!-- 섹션은 이어서 흐른다. page-break는 정답 부록에만 -->
…
</body>
</html>
```

CSS 링크는 넣지 않는다. `render.py`가 `assets/study.css`와 글꼴을 넣는다.

## 표지 `.cover`

```html
<section class="cover">
  <div class="hero">
    <div class="hero-top"><span>과목명</span><span>2026-2 중간고사 범위</span></div>
    <div class="hero-num">06</div>                <!-- 날개에 큰 명조 단원 번호 -->
    <h1>C Standard File I/O</h1>
    <p class="sub">이 단원을 한 줄로</p>
    <svg class="motif" viewBox="0 0 280 84">…단원 내용을 추상화한 작은 그림 (선택)…</svg>
  </div>
  <dl class="meta">
    <div><dt>범위</dt><dd>슬라이드 p.1–41<small>p.42 이후 제외</small></dd></div>
    <div><dt>출처</dt><dd>파일명<small>실습 자료</small></dd></div>
    <div><dt>검증</dt><dd>환경<small>무엇을 직접 돌렸나</small></dd></div>
    <div class="log"><dt>복습 기록</dt><dd><span>당일</span><span>1주 뒤</span><span>시험 전</span></dd></div>   <!-- 인쇄본에 표시하는 네모 칸 -->
  </dl>
  <p class="scope"><span class="tag warn">시험범위 아님</span>제외 범위 설명</p>   <!-- 범위 제한이 있을 때만 -->
  <figure class="map"><div class="label">한 장 요약</div><svg>…</svg></figure>
  <nav class="toc"><div class="label">차례</div>
    <a href="#s01"><span class="n">01</span><span>제목</span><span class="s">p.7–12</span><span class="p">2</span></a>
  </nav>
</section>
```

- `.motif`는 장식이지만 단원 내용과 관련 있어야 한다 (파일 칸, 포인터, 잠금 구간, 트리 등). 파랑 채움(`#2b44b8`)과 파랑 점선만 쓴다. 예전처럼 흰색(`#fff`)으로 그린 모티프도 CSS가 파랑으로 바꿔 보여 준다.
- 차례는 두 단으로 흐른다. 쪽 번호(`.p`)는 `render.py --fix-toc`가 맞춘다.

## 섹션 `.sec` + 머리 `.head`

```html
<section class="sec" id="s02">
  <header class="head">
    <div class="badge"><span class="bn">02</span><span class="src">6주 p.25–41</span></div>
    <div class="title">
      <h2>섹션 제목</h2>
      <p class="lede">핵심 한 문장.</p>
    </div>
  </header>
  <!-- 이후 자식: .rail은 날개에 뜨고, 나머지는 본문 칸에 차례로 쌓인다 -->
</section>
```

섹션은 앞 섹션에 이어서 흐른다. 제목(`.head`)은 다음 블록과 같은 쪽에 놓이도록 CSS가 막아 준다. 새 쪽이 꼭 필요할 때만 `class="sec page-break"`를 쓴다.

`.sec`은 본문을 날개만큼 들여 쓰고, `<aside class="rail">`은 왼쪽 날개에 띄운다(float). 날개 메모는 **관련 본문 블록 바로 앞에** 둔다. 그러면 그 블록 옆에 붙는다. 메모가 본문 블록보다 길어도 본문에 빈칸이 생기지 않고, 다음 메모는 앞 메모 아래로 밀린다. 그래도 메모는 짧게 쓴다.

## 레일 노트와 run-in 머리말

```html
<aside class="rail">
  <div class="note"><span class="tag warn">주의</span>함정 한두 문장</div>
  <div class="note"><span class="tag ok">검증</span>직접 돌린 결과, 환경</div>
</aside>
```

`.tag`는 배경 없는 run-in 머리말이다. 문장 첫 단어가 색과 굵기로만 구분된다. 배지처럼 보이게 꾸미지 않는다.

| 클래스 | 머리말 예 | 쓰는 곳 |
|---|---|---|
| `tag warn` | 주의, 슬라이드 오류 | 함정, 자료의 실수, 시험범위 아님 |
| `tag ok` | 검증, 검산 | 실행하거나 다시 계산한 사실 |
| `tag link` | 연결 | 다른 주차·섹션·카드로 이어짐 |
| `tag add` | 보충, 환경, 미검증 | 자료 밖 내용, 환경에 따라 다름 |
| `tag` (회색) | 참고, 발췌, 상수, 유형, `p.N` | 중립 정보 |

학생 본인의 질문(Q&A 자료)은 `<span class="tag link">10/16 질문</span>`처럼 날짜를 라벨로 쓴다.

## 시그니처 `.sig`

```html
<div class="sig">
  <pre><span class="kw">int</span> <span class="fn">fseek</span>(<span class="kw">FILE</span> *fp, <span class="kw">long</span> offset, <span class="kw">int</span> whence);</pre>
  <dl class="ret">
    <div><dt>fseek</dt><dd>성공 <code>0</code> · 실패 <code>−1</code></dd></div>
  </dl>
  <div class="kv3">…상수 3개가 있으면 (선택)…</div>
</div>
```

## 표 `table.bt`

```html
<table class="bt">
  <thead><tr><th>모드</th><th class="ctr">읽기</th><th>파일이 있으면</th><th>플래그</th></tr></thead>
  <tbody>
    <tr><td class="k">"w"</td><td class="ctr nodot">–</td><td class="hot">내용 삭제</td><td class="m">O_TRUNC</td></tr>
    <tr class="group"><td class="k">"r+"</td><td class="ctr dot">●</td><td><b>처음부터 덮어씀</b></td><td class="m">O_RDWR</td></tr>
  </tbody>
</table>
<p class="tnote">표 아래 각주 한 줄.</p>
```

- `.k`는 첫 열의 키(코드)이고 `.m`은 보조 값(작은 mono, 줄바꿈 없음)이다.
- `.hot`은 위험한 값(빨간 점과 빨간 글자)이다. 표 하나에 두세 개까지만 쓴다.
- 예·아니오 열은 예 `<td class="ctr dot">●</td>`, 아니오 `<td class="ctr nodot">–</td>`로 쓴다. 색만으로 예·아니오를 나누지 않는다(흑백 인쇄와 색약).
- `tr.group`은 행 묶음 사이에 회색 선을 긋는다.

## 세 칸 키-값 `.kv3`

```html
<div class="kv3">
  <div><span class="k">stdin</span><span class="v">fd 0</span><span class="d">키보드 · <code>scanf</code></span></div>
  …3개
</div>
```

## 핵심 공식 `.formula` (별행 수식)

```html
<div class="formula">
  <div class="row"><span class="lhs">위치</span><span class="eq">=</span><span class="rhs">(학번 − START_ID) × sizeof(rec)</span></div>
  <div class="row"><span class="lhs">파일 크기</span><span class="eq">=</span><span class="rhs">(최대 학번 − START_ID + 1) × 28</span></div>
  <p class="ex">예: 학번 <code>1401004</code> → 위치 <code>84</code></p>
</div>
```

- 위아래 선만 있고, 오른쪽에 `(6.1)` 번호가 자동으로 붙는다. 상자, 띠, "핵심" 배지를 붙이지 않는다.
- 섹션당 최대 하나만 쓴다. 다른 곳에서는 "식 (6.1)"로 가리킨다.

## 코드

```html
<pre>…</pre>                          <!-- C 소스: .kw 타입·키워드, .fn 함수, .st 문자열, .c 주석 -->
<pre class="term"><span class="pr">$</span> ls -l <span class="c"># 설명</span></pre>
```

주석 코드는 줄별 설명을 문단으로 쓰지 않고 마커로 단다.

```html
<pre class="anno"><span class="ln">fp = <span class="fn">fopen</span>(argv[1], <span class="st">"wb"</span>);<span class="mk">1</span></span><span class="ln">…</span></pre>
<ol class="notes">
  <li><span class="mk">1</span><span>짧은 설명</span></li>
</ol>
```

- `.anno`는 한 줄을 `<span class="ln">` 하나로 감싼다. 줄 사이에 개행 문자를 넣지 않는다. 마커는 줄 끝에 붙인다.
- 코드 한 줄은 약 75자를 넘기지 않는다. 넘치면 잘린다(`overflow: hidden`).

## 실행 결과 `.out`

```html
<div class="label"><span class="tag ok">실행 결과</span><span class="aside">Ubuntu · gcc 15.2</span></div>
<pre class="out">실제로 본 출력 그대로</pre>
```

## 그림 `figure`과 표 캡션

```html
<figure>
  <div class="label">그림 제목</div>
  <svg viewBox="0 0 540 H" font-family="Pretendard, 'Noto Sans KR', sans-serif">…</svg>
</figure>
```

`figure > .label`에는 "그림 6.N"이 자동으로 붙는다. 표 위 라벨은 `<div class="label tbl">`로 쓰면 "표 6.N"이 붙는다. 표지의 맵에는 번호가 붙지 않는다. SVG 규칙은 `svg.md`에 있다.

## 생각 카드 `.card` (시험지 문항)

```html
<article class="card">
  <aside class="rail">                          <!-- 선택: 카드 메모는 카드 안에 둔다. 번호 아래 날개에 붙는다 -->
    <div class="note"><span class="tag">유형</span>예측 후 실행</div>
    <div class="note"><span class="tag link">연결</span>생각 17</div>
  </aside>
  <div class="card-head">
    <div class="card-no">16</div>              <!-- 토론형: <div class="card-no">16<small>토론형</small></div> -->
    <div class="card-title">질문 제목</div>
    <span class="pill">p.25–41</span>
  </div>
  <div class="card-body">
    <pre class="term">…돌려 볼 명령…</pre>   <!-- 또는 C 코드, 계산 조건 -->
    <ol class="ask"><li><span>예측 질문 1</span></li><li><span>예측 질문 2</span></li></ol>
    <div><div class="label">내 예측</div><div class="write"><div></div><div></div></div></div>
    <p class="hint"><span class="tag">힌트</span><span>답이 아닌 방향 한 줄</span></p>
  </div>
  <div class="cut"><span class="tag ok">정답</span></div>   <!-- 토론형은 "판단 기준" -->
  <div class="answer">
    <p class="verdict">결과 한두 문장.</p>
    ….out / table.bt / 작은 SVG로 이유 설명…
  </div>
</article>
```

- 번호는 날개에 큰 명조로 서고, 카드는 위쪽 굵은 선 하나로 시작한다. 색 띠나 테두리 상자는 쓰지 않는다.
- `.ask`의 짧은 질문은 한 줄에 나란히, 긴 질문은 한 줄씩 놓인다. `li`의 내용은 반드시 `<span>` 하나로 감싼다. 감싸지 않으면 `<code>`마다 칸이 쪼개진다.
- 예측 칸(`.write`)은 두 줄이 기본이다. 계산이나 그림을 그려야 하는 문항만 세 줄로 늘린다.
- 카드는 쪽 경계에서 잘리지 않는다(`break-inside: avoid`). 보통 크기의 카드는 한 쪽에 두 장씩 들어간다. 한 쪽(약 260mm)을 넘는 카드는 통째로 밀려 빈 쪽을 만들므로 설명 표를 줄이거나 카드를 둘로 나눈다.
- 카드 섹션도 앞 섹션에 이어서 흐른다. `.head`의 `.lede`에 풀이 순서를 한 문장으로 쓴다.

## 정답 부록 `.appendix` (정답을 뒤로 모을 때)

카드에서는 `.cut`과 `.answer`를 빼고 `.card-body` 끝에 참조 한 줄만 둔다.

```html
<p class="answer-ref">정답: 부록 A.1</p>
```

맨 뒤에 부록 섹션을 하나 둔다. 정답 내용은 카드 안에 쓰던 `.answer`와 같다.

```html
<section class="sec page-break appendix" id="sA">
  <header class="head">
    <div class="badge"><span class="bn">A</span><span class="src">정답</span></div>
    <div class="title"><h2>부록: 생각해 보기 정답</h2><p class="lede">예측을 다 적은 뒤에 펼친다.</p></div>
  </header>
  <div>
    <div class="label">A.1 질문 제목</div>
    <div class="answer"><p class="verdict">결과 한두 문장.</p>…</div>
  </div>
</section>
```

## 복습 질문 `table.qa`

```html
<table class="qa">
  <thead><tr><th></th><th>질문</th><th class="fold">정답 · 여기서 접기</th></tr></thead>
  <tbody>
    <tr><td class="no"><span class="box"></span><span class="num">01</span></td>
        <td class="q">질문</td>
        <td class="a">답 한두 문장. <span class="p">p.7–12</span></td></tr>
  </tbody>
</table>
```

## 인라인

- `<code>`는 코드·명령·파일명·상수에 쓴다.
- `<b>`는 문단(또는 표)마다 핵심어 하나에만 쓴다. 파란색으로 표시된다.
- 기호 `→ × − ·`는 Pretendard에 있다. `▲ ✂ ★` 같은 기호는 대체 글꼴로 찍히니 쓰지 않는다.
