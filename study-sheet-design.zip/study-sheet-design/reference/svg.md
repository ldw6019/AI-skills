# SVG 다이어그램 가이드

이 디자인에서 그림은 장식이 아니라 **줄글을 대신하는 주된 수단**이다. 문단 세 줄로 설명할 구조라면 그림 하나로 바꾼다.
한 섹션에 그림 1~2개를 목표로 한다.

## 공통 규칙

- `<figure><div class="label">제목</div><svg viewBox="0 0 540 H">`처럼 쓴다. 본문 폭은 540, 표지 전체 폭은 680이다. `width`/`height` 속성은 넣지 않는다(CSS가 100%로 맞춘다).
- 루트 `<svg>`에 `font-family="Pretendard, 'Noto Sans KR', sans-serif"`를 단다. 코드 글자는 `font-family="JetBrains Mono, Pretendard, monospace"`로 쓴다. **Pretendard를 빼면 한글과 화살표가 굴림으로 찍힌다.**
- 글자 크기(viewBox 단위)는 본문 10~11, 보조 8.5~9.5, 강조 제목 13이다. 8 아래로는 내려가지 않는다.
- 선 굵기는 기본 1, 강조 1.1~1.2, 보조 0.8이다.
- 화살표는 문서 머리의 공용 marker를 쓴다. `marker-end="url(#ahA)"`
- 색은 아래 팔레트만 쓴다. 의미는 본문과 같다.

| 용도 | 채움 | 선·글자 |
|---|---|---|
| 개념·데이터 (주인공) | `#eef1fb` / 진하게 `#dfe5fa` / 더 진하게 `#b9c5f2` | `#2b44b8`, 글자 `#1b2a7a` |
| 커널·하위 계층·외부 | `#ffffff` 또는 `#f4f5f7` | `#17191e` |
| 비어 있음·구멍·미사용 | `#fafbfc` | `#8b919c` 점선 `stroke-dasharray="3 2"` |
| 위험·패딩·금지 | `#fcefe9` + `url(#hatch)` | `#c2461d` |
| 성공·통과 | `#e8f4ee` | `#1d7a57` |
| 보조 설명 글자 | | `#4b515c`, 더 흐리게 `#8b919c` |

- 동작을 가리키는 라벨(`fseek(fp, 84, SEEK_SET)` 같은 것)은 파란 알약으로 쓴다. 채움 `#2b44b8`, 흰 글자, `rx`는 높이의 절반이다. 알약 폭은 글자 수 × 6.2 + 20 정도로 넉넉히 잡는다.
- 수치 눈금(오프셋, 바이트, 시간)은 mono 9, `#8b919c`이다. 강조할 눈금 하나만 파랑과 굵게 쓴다.
- 그림 아래 왼쪽에는 읽는 법 한 줄(`#4b515c`), 오른쪽에는 결론 숫자(굵게, `#17191e`)를 둔다.

## 패턴 (언제 무엇을 그리나)

| 패턴 | 이럴 때 | 견본 위치 |
|---|---|---|
| 레인 맵 | 두 계층의 대응 (라이브러리 ↔ 시스템 콜, 사용자 ↔ 커널) | 표지 "한 장 요약" |
| 상자와 포인터 | 구조체가 다른 것을 가리킴 (`FILE` → 버퍼, fd → 파일 테이블) | 01 "FILE 안에 들어 있는 것" |
| 메모리 막대 | 바이트 배치, 패딩, 필드 오프셋, 비트 필드(`st_mode`) | 02 "메모리 배치" |
| 칸 배열 | 파일 속 레코드, 배열 인덱스, 구멍, 위치 계산 | 02 "stcreate2로 저장한 파일" |
| 타임라인 | 프로세스 둘의 잠금·대기·해제 순서, 시스템 콜 순서 | 아래 스니펫 |
| 트리 | 디렉터리 구조, 링크, i-노드 연결, 프로세스 계층 | 아래 스니펫 |
| 상태 전이 | 파일 위치 포인터 이동, 모드 전환, 버퍼 상태 | 상자와 화살표로 |

## 스니펫: 타임라인 (두 행위자)

```html
<svg viewBox="0 0 540 120" font-family="Pretendard, 'Noto Sans KR', sans-serif">
  <g font-size="10" font-weight="700" fill="#17191e"><text x="0" y="38">P1</text><text x="0" y="88">P2</text></g>
  <g stroke="#e1e4e9"><line x1="40" y1="34" x2="530" y2="34"/><line x1="40" y1="84" x2="530" y2="84"/></g>
  <!-- 잡고 있는 구간: 파랑 막대 / 기다리는 구간: 빗금 -->
  <rect x="60" y="26" width="180" height="16" rx="2" fill="#dfe5fa" stroke="#2b44b8"/>
  <text x="150" y="37.5" font-size="9" fill="#1b2a7a" text-anchor="middle" font-family="JetBrains Mono, Pretendard, monospace">F_WRLCK</text>
  <rect x="120" y="76" width="120" height="16" rx="2" fill="url(#hatch)" stroke="#c2461d"/>
  <text x="180" y="104" font-size="9" fill="#c2461d" text-anchor="middle">대기 (F_SETLKW)</text>
  <rect x="240" y="76" width="140" height="16" rx="2" fill="#dfe5fa" stroke="#2b44b8"/>
  <line x1="240" y1="44" x2="240" y2="74" stroke="#2b44b8" marker-end="url(#ahA)"/>
  <text x="246" y="62" font-size="8.5" fill="#2b44b8">해제 → 획득</text>
  <g font-family="JetBrains Mono, Pretendard, monospace" font-size="8.5" fill="#8b919c" text-anchor="middle">
    <text x="60" y="118">t0</text><text x="240" y="118">t1</text><text x="380" y="118">t2</text></g>
</svg>
```

## 스니펫: 트리 (디렉터리·링크)

```html
<svg viewBox="0 0 540 112" font-family="JetBrains Mono, Pretendard, monospace" font-size="10">
  <text x="0" y="16" fill="#17191e" font-weight="600">/home/u</text>
  <path d="M10 22 V92 M10 46 H40 M10 92 H40" fill="none" stroke="#8b919c"/>
  <text x="46" y="50" fill="#1b2a7a">a.txt</text><text x="46" y="96" fill="#1b2a7a">b.txt</text>
  <g stroke="#2b44b8" fill="none" marker-end="url(#ahA)"><path d="M92 46 L246 64"/><path d="M92 92 L246 78"/></g>
  <rect x="250" y="54" width="140" height="34" rx="3" fill="#dfe5fa" stroke="#2b44b8"/>
  <text x="320" y="69" text-anchor="middle" fill="#1b2a7a" font-weight="600">i-node 1234</text>
  <text x="320" y="82" text-anchor="middle" fill="#4b515c" font-size="9">링크 수 2</text>
  <text x="404" y="75" fill="#4b515c" font-size="9.5" font-family="Pretendard, sans-serif">이름 둘, 파일 하나 (하드 링크)</text>
  <!-- 심볼릭 링크는 점선 화살표(stroke-dasharray="3 2")로 '경로 문자열' 상자를 가리키게 그린다 -->
</svg>
```

## 점검

- 글자가 상자 밖으로 나가지 않았는지 (특히 알약, 좁은 칸의 `score` 같은 짧은 필드)
- 눈금 숫자가 겹치지 않는지 (간격 30 미만이면 하나를 위로 올린다)
- 미리보기에서 그림이 너무 작으면 viewBox 폭을 줄인다 (같은 폭에 더 크게 그려진다)
- 그림 속 숫자는 본문·실행 결과와 같은 값인지 확인한다. 그림에만 있는 숫자는 만들지 않는다.
