---
name: study-sheet-design
description: Design system and PDF renderer for course study sheets. Lays out an already-written, verified study sheet (typically the STUDY.md from course-study-builder) as a polished A4 PDF with a left meta rail, semantic colors, SVG diagrams, self-test cards and a fold-to-hide review table. Use at course-study-builder's render step when a Chromium-family browser is available, or when the student asks to make an existing study sheet prettier, better designed, 예쁘게, 디자인, or less AI-looking. Not for writing or verifying study content; course-study-builder does that.
---

# Study sheet design

`course-study-builder`이 **무엇을** 쓸지(내용·검증·STUDY.md)를 정하고, 이 스킬은 **어떻게 보일지**(조판·PDF)를 정한다.
두 스킬을 같이 쓸 때는 course-study-builder 6장(Rendering)의 CSS와 PDF 방법 대신 이 스킬을 따른다. STUDY.md는 원본으로 그대로 남긴다.

## 쓸 수 있는지 먼저 확인

```
python "<이 스킬 폴더>/scripts/render.py" --check
```

브라우저 경로가 출력되면 이 스킬을 쓴다. 실패하면 이 스킬을 쓰지 않고 course-study-builder의 Markdown 렌더러(`render_study.py`)로 PDF를 만든다. 학생에게는 보고에서 한 줄로 알린다. 브라우저를 설치하려고 오래 매달리지 않는다.

```
study-sheet-design/
  SKILL.md                 이 파일: 원칙, 순서, 대응표, 점검
  reference/components.md  컴포넌트 HTML 스니펫과 쓰는 규칙
  reference/svg.md         SVG 팔레트, 패턴, 스니펫
  examples/specimen.html   모든 컴포넌트가 실제로 쓰인 5쪽 견본 (6주차 C Standard File I/O)
  assets/study.css         디자인 토큰 + 컴포넌트 스타일
  assets/fonts/            Pretendard 400–800, JetBrains Mono 400·600 (오프라인 렌더용)
  scripts/render.py        HTML → PDF, PNG 미리보기, 대체 글꼴·빈 페이지 점검
```

## 원칙

1. **색은 의미로만 쓴다.** 색은 글자, 선, 옅은 면에만 입힌다. 색 띠나 배지에는 쓰지 않는다. 같은 색은 문서 전체에서 같은 뜻이다.

   | 색 | 뜻 | 대표 사용처 |
   |---|---|---|
   | 파랑 `#2b44b8` | 개념, 주인공 데이터 | 섹션 번호, 함수 이름, 공식, 다이어그램 주체, `<b>` |
   | 빨강 `#c2461d` | 주의, 위험 | 레일 주의, 표 `.hot`, 패딩·금지 영역 |
   | 초록 `#1d7a57` | 검증된 것 | 실행 결과 줄, 정답 영역, 레일 검증·검산 |
   | 호박 `#9c5f0e` | 자료 밖, 힌트 | 힌트 띠, 레일 보충·환경·미검증 |
   | 회색 | 메타 | 쪽 번호, 라벨, 보조 글자 |

2. **줄글을 쓰지 않고 슬롯을 채운다.** 섹션에 허용되는 줄글은 `.lede` 한 문장뿐이다. 나머지는 정의, 표, 공식, 주석 코드, 그림, 레일 노트 같은 컴포넌트 안에 들어간다. 문단으로 쓰고 싶어지면 표나 SVG로 바꿀 수 있는지 먼저 본다.
3. **메타는 왼쪽 레일로 보낸다.** 쪽수, 주의, 보충, 검증, 연결, 학생 질문을 본문 문장에 섞지 않는다.
4. **그림을 적극적으로 쓴다.** 구조, 배치, 순서, 대응 관계는 SVG로 그린다. 섹션당 1~2개다. 규칙은 `reference/svg.md`에 있다.
5. **장식도 내용에서 가져온다.** 표지 모티프, 알약 라벨, 빗금은 단원 내용(파일 칸, 잠금 구간, 포인터)을 그린 것이어야 한다. 이모지, 무의미한 아이콘, 무지개 박스는 쓰지 않는다.
6. **정직성 규칙은 그대로 지킨다.** 레일의 쪽 번호는 원본(STUDY.md 또는 슬라이드)에 있는 값만 쓴다. 원본에 범위(`p.25–41`)만 있으면 범위를 쓴다. **단일 쪽(`p.27`)을 추측해서 만들지 않는다.** 실행 결과는 STUDY.md에 있는 관찰값만 옮긴다.

## 금지 패턴 (AI가 만든 티가 나는 것)

템플릿 UI에서 흔히 보이는 장치는 쓰지 않는다. 위계는 인쇄물의 방식으로 만든다. 선, 여백, 글자 굵기, 번호가 그 수단이다.

| 쓰지 않는다 | 대신 |
|---|---|
| 왼쪽 굵은 색 띠가 달린 상자 (border-left 콜아웃) | 핵심 식은 위아래 선 + 오른쪽 식 번호 `(6.1)`의 별행 수식(`.formula`). 출력은 옅은 면(`.out`). 경고는 레일로 |
| 알약·배지 라벨 (`핵심`, `NEW`, 색 칠한 작은 태그) | run-in 머리말: 문장 첫 단어를 색과 굵기로만 (`주의 a와 a+는…`) |
| 제목 위의 작은 키커(eyebrow) 글자 | 없앤다. 분류가 필요하면 `.lede` 문장 안에 쓴다 |
| 이모지, 의미 없는 아이콘, 무지개색 박스 | 색 의미표의 네 색만 쓴다 |
| 사선 그라데이션 배경·글자, 그림자 카드, 둥근 모서리 남발 | 모서리는 2~4px. 면은 단색(별색)에 점 무늬 정도까지만 쓰고, 그림자는 쓰지 않는다 |
| 색칠한 작은 값 칩 (`fd 0` 배지 등), 블록 왼쪽 위의 작은 라벨 (`C`, `SHELL`, 카드 번호 위 "생각") | 값은 회색 mono 글자로. 블록 종류는 모양으로 구분한다 (C는 밝은 면, 셸은 어두운 면) |
| "라벨: 값" 나열 문단 | 표, `.kv3`, 그림 캡션 |

그림과 표에는 `그림 6.2`, `표 6.1`처럼 번호가 자동으로 붙는다(`<body style='--unit: "6"'>`). 본문과 레일에서 "식 (6.1)", "그림 6.3"처럼 번호로 가리키면 교과서처럼 읽힌다.

## 작업 순서

1. **읽기**: STUDY.md(또는 학생이 준 정리본)를 끝까지 읽는다. 시험범위, 출처, 검증 환경, 섹션, 생각 카드, 복습 질문을 목록으로 뽑는다. course-study-builder이 있으면 먼저 `render_study.py STUDY.md --lint-only`로 원본을 점검하고, 경고는 STUDY.md에서 고친다(HTML에서 고치지 않는다).
2. **견본 보기**: `examples/specimen.html`을 열어 컴포넌트가 실제로 어떻게 생겼는지 확인한다. 처음 쓰는 컴포넌트는 `reference/components.md`도 본다.
3. **쪽 계획**: 표지 1쪽(맵과 차례 포함), 섹션당 1~2쪽, 생각 카드는 한 쪽에 1개(짧으면 2개), 복습 1~2쪽을 기본으로 잡는다. 모든 섹션은 `page-break`로 새 쪽에서 시작한다. 쓰기 전에 예상 쪽수를 센다. 기본 분량(카드 8~9개, 복습 약 20행)이면 카드만 5~9쪽이 된다. 전체가 20쪽을 넘을 것 같으면 짧은 카드를 한 쪽에 두 개씩 넣고, 정리 모음 표를 한 쪽에 모은다. 쪽수를 맞추려고 카드나 질문을 빼지 않는다. 내용 분량은 course-study-builder이 정한다.
4. **조판**: STUDY.md와 같은 폴더에 `N주차_공부자료(Topic).html`을 쓴다. 길면 표지, 섹션별, 카드, 복습 순서로 Write와 Edit를 나눠 이어 쓴다. 대응표는 아래에 있다.
5. **렌더**:
   ```
   python "<이 스킬 폴더>/scripts/render.py" "N주차_공부자료(Topic).html" --source STUDY.md --preview "<스크래치 폴더>/preview"
   ```
   같은 이름의 PDF가 HTML 옆에 생긴다. 꼬리말은 `<meta name="footer">`에서 가져온다. `--source`를 주면 HTML과 STUDY.md를 대조한다. 생각 카드 수, 복습 질문 수, 원본에 없는 쪽 번호를 확인하고 어긋나면 `대조:` 경고를 낸다. 경고가 나오면 HTML을 STUDY.md에 맞춘다.
6. **보고 고치기**: 미리보기 PNG를 **모든 쪽** 열어 아래 점검표로 확인하고, 고친 뒤 다시 렌더한다. 차례의 쪽 번호도 이때 맞춘다.
7. **마무리**: 학생 폴더에는 STUDY.md(원본), HTML, PDF만 남긴다. `--keep-html`을 쓰지 않으면 렌더용 임시 HTML은 자동으로 지워진다. 미리보기는 스크래치 폴더에 둔다.

## STUDY.md → 컴포넌트 대응표

| STUDY.md | 컴포넌트 |
|---|---|
| 제목, 출처 줄, 범위 주의 | `.cover`의 `.hero`, `.meta`, `.scope` |
| `0. 한 장 요약` 코드 트리 | `.cover .map` SVG (레인 맵이나 흐름도). ASCII 트리를 그대로 옮기지 않는다. 트리 각 줄의 `(p.N)`은 해당 노드 옆에 회색 mono 9 글자(`#8b919c`)로 남긴다. 범위 밖 노드는 점선 상자로 그린다 |
| `## 섹션 (p.A~B)` | `section.sec` + `.head` (`.bn` 번호, `.src` 쪽 범위, `.lede`에는 핵심 개념의 첫 문장. 둘째 문장이 있으면 본문 첫 블록이나 표 캡션으로) |
| `> **핵심**:` | 섹션의 요지면 `.lede`. 아니면 본문 `<p>`에 run-in 머리말 `<span class="tag link">핵심</span>`. 외울 식이면 `.formula` |
| 함수 원형과 반환값 | `.sig` (`pre` + `dl.ret`, 상수가 있으면 `.kv3`) |
| 비교표, 옵션표 | `table.bt` (`.k`, `.m`, `.hot`, `●` 열) |
| 핵심 공식, 외울 식 | `.formula` (섹션당 하나) |
| 메모리, 구조, 흐름 ASCII 그림 | `figure` + SVG |
| 예제 코드와 줄별 설명 | `pre.anno` + `ol.notes` |
| 셸 명령 | `pre.term` |
| `` ```out `` 실행 결과 | 라벨 `tag ok 실행 결과` + `pre.out` |
| `> **주의**:` | 레일 `tag warn` |
| `> **참고**:` (학생 질문) | 레일 `tag link` (날짜 라벨) 또는 회색 `tag` |
| `(보충: …)`, `(미검증)` | 레일 `tag add` |
| `[시험범위 아님]` 섹션 | `.head`의 `.kicker`에 "시험범위 아님", 레일에 `tag warn` |
| 공식·명령어 모음 | `table.bt` 여러 개와 `.kv3` (레일은 비워도 된다) |
| `실습 자료 현황` 표 | `table.bt`: 항목은 `.k`, 원본 쪽은 `.m`, 상태 열. 미완성·오류 항목만 `.hot` |
| `복습 질문` 표 | `table.qa` |
| `생각 N` 카드, `[[예측]]`, `> **힌트**:`, `[[정답]]` | `.card`: `.ask`, `.write`, `.hint`, `.cut`, `.answer` |
| `[토론형]` 카드 | 같은 `.card`. `.pill`에 `p.A–B · 토론형`, `.cut` 머리말은 `판단 기준`, `.verdict`에는 판정이 아니라 기준 한 문장, 그 아래 `table.bt` (선택지 · 맞는 경우 · 비용) |

### 정답 부록 모드 (`--answers appendix`에 해당)

학생이 인쇄본에서 정답을 가리고 싶어 하면 카드 안에 `.cut`과 `.answer`를 넣지 않는다. 대신 카드 끝에 `<p class="answer-ref">정답: 부록 A.N</p>`을 두고, 맨 뒤 `section.sec.page-break.appendix`에 카드 순서대로 `<div class="answer">`를 모은다. 각 정답 앞에 `<div class="label">A.N 카드 제목</div>`을 단다. 스니펫은 `reference/components.md`에 있다.

### 영어 출력

`<html lang="en">`으로 쓰면 그림·표 캡션이 `Figure 6.1`, `Table 6.1`로 바뀐다. 레일 머리말(`Warning`, `Verified`, `Note`, `Hint`, `Answer`)과 표지 라벨은 HTML에 영어로 직접 쓴다.

## 렌더 점검표

- [ ] `render.py` 출력이 "글꼴: Pretendard / JetBrains Mono만 사용"이다 (대체 글꼴이 있으면 SVG의 font-family나 기호를 고친다)
- [ ] "거의 빈 페이지" 경고가 없다 (있으면 카드가 넘친 것이다. 줄이거나 나눈다)
- [ ] 카드, 표, 그림이 쪽 경계에서 잘리지 않았다
- [ ] 레일 노트가 해당 본문 옆에 있고, 레일 때문에 본문에 큰 빈칸이 생기지 않았다
- [ ] ①②③ 마커가 한 열로 정렬됐고, 코드 줄이 잘리지 않았다
- [ ] SVG 글자가 상자 밖으로 나가거나 겹치지 않았다
- [ ] 차례의 쪽 번호가 실제와 맞는다
- [ ] 쪽 번호와 실행 결과는 원본에 있는 값만 썼다
- [ ] `--source STUDY.md` 대조에서 `대조:` 경고가 없다 (카드 수, 복습 질문 수, 원본에 없는 쪽 번호)
- [ ] 한 장 요약 맵의 노드마다 `p.N`이 있다
- [ ] 정답 부록 모드라면 카드 안에 `.answer`가 하나도 없다
- [ ] 꼬리말은 2쪽부터 나온다 (표지에는 일부러 없다)

## 환경

- Edge, Chrome, Chromium 중 하나가 필요하다. 못 찾으면 `STUDY_BROWSER` 환경변수에 실행 파일 경로를 넣는다. Chrome 131 이상이어야 `@page` 꼬리말(쪽 번호)이 나온다. `--check`로 찾은 경로를 확인할 수 있다.
- Linux에서 root로 실행하면 Chromium이 샌드박스 오류로 멈추는 경우가 많다. 이때 `render.py`가 `--no-sandbox`를 자동으로 붙인다. 다른 경우에도 필요하면 `STUDY_NO_SANDBOX=1`을 설정한다. PDF 생성이 실패하면 브라우저의 오류 출력 끝부분이 함께 표시된다.
- 브라우저가 없으면 이 스킬 대신 course-study-builder의 Markdown 렌더러를 쓴다 (맨 위 "쓸 수 있는지 먼저 확인").
- 점검과 미리보기에는 PyMuPDF(`pip install pymupdf`)를 쓴다. 없으면 PDF만 만들고 점검은 건너뛴다.
- 표지 패널과 터미널 블록은 진한 색이라 흑백 인쇄 시 토너를 많이 쓴다. 학생이 인쇄용을 원하면 `pre.term`을 밝은 `pre`로 바꾼다.
