---
name: study-sheet-design
description: Design system and PDF renderer for course study sheets. Lays out an already-written, verified study sheet (typically the STUDY.md from course-study-builder) as a textbook-style A4 PDF: serif body and headings, margin notes in a left wing, exam-paper style self-test cards, a fold-to-hide review table, and pages that flow without half-empty pages. Use at course-study-builder's render step when a Chromium-family browser is available, or when the student asks to make an existing study sheet prettier, better designed, 예쁘게, 디자인, or less AI-looking. Not for writing or verifying study content; course-study-builder does that.
---

# Study sheet design

`course-study-builder`가 **무엇을** 쓸지(내용·검증·STUDY.md)를 정하고, 이 스킬은 **어떻게 보일지**(조판·PDF)를 정한다.
두 스킬을 같이 쓸 때는 course-study-builder 6장(Rendering)의 CSS와 PDF 방법 대신 이 스킬을 따른다. STUDY.md는 원본으로 그대로 남긴다.

## 쓸 수 있는지 먼저 확인

```
python "<이 스킬 폴더>/scripts/render.py" --check
```

브라우저 경로가 출력되면 이 스킬을 쓴다. 실패하면 이 스킬을 쓰지 않고 course-study-builder의 Markdown 렌더러(`render_study.py`)로 PDF를 만든다. 학생에게는 보고에서 한 줄로 알린다. 브라우저를 설치하려고 오래 매달리지 않는다.

```
study-sheet-design/
  SKILL.md                 이 파일: 판면, 원칙, 순서, 대응표, 점검
  reference/components.md  컴포넌트 HTML 스니펫과 쓰는 규칙
  reference/svg.md         SVG 팔레트, 패턴, 스니펫
  examples/specimen.html   모든 컴포넌트가 실제로 쓰인 견본 (6주차 C Standard File I/O)
  assets/study.css         디자인 토큰 + 컴포넌트 스타일 (v1.0)
  assets/fonts/            Noto Serif KR 400·700 (현대 한글 전체 서브셋, OFL), Pretendard 400–800, JetBrains Mono 400·600
  scripts/scaffold.py      STUDY.md → HTML 초안 (모든 컴포넌트를 채우고 손볼 곳은 TODO로 표시)
  scripts/render.py        HTML → PDF, 미리보기, STUDY.md 대조, 차례 쪽 번호, 쪽 끝 제목·대체 글꼴 점검
```

## 판면 (수험서·교재)

```
┌ 날개 31mm ┬ 6mm ┬ 본문 145mm ─────────────────────────────┐
│ 01         │     │ 섹션 제목 (명조 17pt)                     │
│ 6주 p.7–12 │     │ 리드 한 문장 (명조)                       │
│            │     │                                          │
│ 주의 …     │     │ 본문·표·코드·그림 (본문은 명조 9.6pt)       │
│ (고딕 메모) │     │                                          │
├────────────┴─────┴──────────────────────────────────────────┤
│ 16         │     │ 문항 제목 (명조)                  p.25–41 │  ← 생각 카드: 시험지 문항
│ 유형·연결  │     │ (a) … (b) …  / 내 예측 ____ / 힌트 / 정답  │
└──────────────────────────────────────────────────────────────┘
```

- **글꼴 셋, 역할 셋.** 본문·제목·번호는 Noto Serif KR(명조), 날개 메모·표·라벨·메타는 Pretendard(고딕), 코드는 JetBrains Mono. 교과서의 "본문 명조, 메모 고딕" 대비를 그대로 쓴다. 고정폭 글꼴은 코드와 코드 값에만 쓴다.
- **날개 메모는 본문 옆에 떠 있다.** `<aside class="rail">`을 관련 본문 블록 바로 앞에 두면 그 블록 옆 날개에 붙는다. 메모가 길어도 본문에 빈칸이 생기지 않는다.
- **쪽은 이어서 흐른다.** 섹션마다 새 쪽을 쓰지 않는다. 섹션 제목은 다음 블록과 함께 넘어가고(제목만 쪽 끝에 남지 않는다), 카드·표의 행·그림·코드는 쪽 경계에서 잘리지 않는다. 새 쪽은 정답 부록처럼 따로 떼어 쓰는 부분에만 `page-break`로 준다.
- **힘은 한 곳에만.** 표지의 큰 명조 단원 번호와 제목이 이 문서의 얼굴이다. 나머지는 선, 여백, 글자 굵기로 조용히 위계를 만든다.

## 원칙

1. **색은 강조색 하나와 의미 색 셋이다.**
   - **단원 강조색**은 과목이나 단원 분위기를 보고 고른다(`scaffold.py --accent`). 단원 번호, 섹션 머리 선, 개념 강조 `<b>`, 그림의 주인공, 지도 상자에 쓴다. 한 문서 안에서는 하나만 쓰고, 아래 의미 색과 헷갈리지 않는 색을 고른다. 고르기 어려우면 기본 남색을 쓴다.

     | 예 | 값 | 어울리는 과목 |
     |---|---|---|
     | 남색 (기본) | `#2b44b8` | 프로그래밍, 공학, 수학 |
     | 청록 | `#0f6a64` | 생명, 화학, 지구과학 |
     | 자주 | `#7a2b5a` | 인문, 언어, 예술 |
     | 황토 | `#8a4a0f` | 경제, 경영, 사회 |

   - **의미 색**은 문서마다 같다. 뜻이 정해져 있어 바꾸지 않는다.

     | 색 | 뜻 | 대표 사용처 |
     |---|---|---|
     | 빨강 `#b8401a` | 주의, 위험 | 날개 주의, 표 `.hot`, 시험범위 아님, 패딩·금지 영역 |
     | 초록 `#1b7350` | 검증된 것 | 실행 결과, 정답 영역, 날개 검증·검산 |
     | 호박 `#8f560b` | 자료 밖, 힌트 | 힌트 띠, 날개 보충·환경·미검증 |
     | 회색 `#6b707a` 이상 | 메타 | 쪽 번호, 라벨, 보조 글자 |

   - 색은 글자, 선, 옅은 면에만 입힌다. 흑백으로 인쇄해도 뜻이 남도록 머리말 글자(`주의`, `검증`, `정답`)를 항상 함께 쓴다.
   - **읽히는 크기**: 본문 10.4pt(행간 1.72), 표·코드 9.2~9.6pt, 날개 메모·라벨·쪽 번호 같은 작은 글자도 9pt 이상. 회색 글자는 `#6b707a`보다 옅게 쓰지 않는다.

2. **줄글을 줄이고 슬롯을 채운다.** 섹션의 줄글은 `.lede` 한 문장이 기본이다. 나머지는 정의, 표, 공식, 주석 코드, 그림, 날개 메모 같은 컴포넌트 안에 들어간다.
3. **메타는 날개로 보낸다.** 쪽수, 주의, 보충, 검증, 연결, 학생 질문을 본문 문장에 섞지 않는다.
4. **그림을 적극적으로 쓴다.** 구조, 배치, 순서, 대응 관계는 SVG로 그린다. 규칙은 `reference/svg.md`에 있다.
5. **장식도 내용에서 가져온다.** 표지 모티프와 빗금은 단원 내용(파일 칸, 잠금 구간, 포인터)을 그린 것이어야 한다.
6. **정직성 규칙은 그대로 지킨다.** 쪽 번호는 원본(STUDY.md)에 있는 값만 쓴다. 원본에 범위(`p.25–41`)만 있으면 범위를 쓴다. **단일 쪽이나 새 범위를 추측해서 만들지 않는다.** 실행 결과는 STUDY.md의 관찰값을 공백까지 그대로 옮긴다.
7. **쪽수 목표는 없다.** 분량은 강의 자료가 정한다(한 주에 슬라이드 50~80장이면 자료도 길다). 이 스킬이 지키는 것은 밀도다: 절반 넘게 빈 쪽이 없고, 제목만 쪽 끝에 남지 않고, 카드나 질문을 쪽수 때문에 빼지 않는다.

## 금지 패턴 (AI가 만든 티가 나는 것)

| 쓰지 않는다 | 대신 |
|---|---|
| 왼쪽 굵은 색 띠가 달린 상자 (border-left 콜아웃) | 핵심 식은 위아래 선 + 식 번호 `(6.1)`의 `.formula`. 경고는 날개로 |
| 알약·배지 라벨, 색칠한 작은 값 칩 | run-in 머리말: 문장 첫 단어를 색과 굵기로만 (`주의 a와 a+는…`) |
| 제목 위 키커, 대문자처럼 자간을 벌린 작은 라벨 | 없앤다. 분류가 필요하면 `.lede` 문장 안에 쓴다 |
| 고정폭 글자로 쓴 메타(쪽 범위, 번호, 날짜) | 고딕 작은 글자. 고정폭은 코드에만 |
| 가운뎃점(·)으로 이어 붙인 메타 문구 | 줄을 나누거나 쉼표. 내용 속 나열(`fgetc · fgets`)은 괜찮다 |
| 쪽 전체를 덮는 색 면, 카드 머리 색 띠, 그림자, 사선 그라데이션 | 선, 여백, 글자 굵기. 모서리는 2px 안팎 |
| 이모지, 의미 없는 아이콘, 무지개색 상자 | 색 의미표의 네 색만 쓴다 |

그림과 표에는 `그림 6.2`, `표 6.1`처럼 번호가 자동으로 붙는다(`<body style='--unit: "6"'>`). 본문과 날개에서 "식 (6.1)", "그림 6.3"처럼 번호로 가리킨다.

## 작업 순서

1. **읽기**: STUDY.md를 끝까지 읽는다. course-study-builder가 있으면 먼저 `render_study.py STUDY.md --lint-only`로 원본을 점검하고, 경고는 STUDY.md에서 고친다(HTML에서 고치지 않는다).
2. **견본 보기**: `examples/specimen.html`을 보고 컴포넌트 생김새를 확인한다. 처음 쓰는 컴포넌트는 `reference/components.md`도 본다.
3. **초안 만들기**:
   ```
   python "<이 스킬 폴더>/scripts/scaffold.py" STUDY.md --course "과목명" --term "2026-2 중간고사" --accent "#2b44b8"
   ```
   `--accent`에는 원칙 1의 표를 보고 과목에 맞는 강조색을 넣는다(생략하면 남색). STUDY.md 옆에 `N주차_공부자료(Topic).html`이 생긴다. 표지(단원 번호, 범위·출처·검증, 복습 기록 칸), 한 장 요약 맵, 차례, 섹션, 날개 메모, 생각 카드, 복습 표가 이미 채워져 있다. 쪽 번호, 실행 결과, 카드, 질문은 STUDY.md에서 그대로 옮긴 것이다. 정답을 뒤로 모으려면 `--answers appendix`, 영어는 `--lang en`(제목으로 자동 판단).
4. **다듬기**: `<!-- TODO -->` 주석을 찾아 손으로 다듬는다.
   - ASCII 그림과 STUDY.md의 SVG는 `reference/svg.md` 기준으로 다시 그리고 그림 제목을 단다.
   - 표지의 한 줄 요약(`.sub`)을 쓰고, 어울리면 모티프를 넣는다.
   - 섹션의 핵심 식이 있으면 `.formula`로 바꾼다.

   내용(값, 쪽 번호, 결과)은 HTML에서 바꾸지 않는다. 바꿀 것이 있으면 STUDY.md를 고친다. 다듬기 전이라면 `--force`로 초안을 다시 만들 수 있지만, `--force`는 손본 HTML을 덮어쓴다.
5. **렌더**:
   ```
   python "<이 스킬 폴더>/scripts/render.py" "N주차_공부자료(Topic).html" --source STUDY.md --fix-toc --preview "<스크래치 폴더>/preview"
   ```
   같은 이름의 PDF가 HTML 옆에 생긴다. 렌더러가 확인하는 것:
   - `대조:` HTML과 STUDY.md의 생각 카드 수, 복습 질문 수, 원본에 없는 쪽 번호와 쪽 범위, `pre.out`의 줄이 STUDY.md `` ```out `` 블록에 그대로 있는지(줄 끝 공백만 무시, 줄을 덜어 내는 것은 괜찮다)
   - `차례:` PDF의 차례 링크가 가리키는 실제 쪽과 차례 숫자. `--fix-toc`면 HTML을 고쳐 다시 렌더한다
   - `쪽 끝 제목:` 섹션 제목 아래에 본문 없이 쪽이 끝난 곳
   - `TODO:` 다듬지 않은 곳의 수, 대체 글꼴, 거의 빈 쪽

   학생은 이 자료의 쪽 번호로 슬라이드를 다시 찾고 실행 결과를 시험 답의 근거로 쓴다. `대조:` 경고는 꾸밈 문제가 아니라 내용 오류로 다룬다. 묶음 섹션의 머리(`.src`)처럼 원본에 맞는 범위가 없으면 범위를 지어내지 말고 `카드 9개`, `20문항` 같은 말로 쓴다.
6. **보고 고치기**: 미리보기 PNG를 모든 쪽 열어 아래 점검표로 확인하고, 고친 뒤 다시 렌더한다. 긴 자료는 표지, 첫 섹션, 카드 쪽, 복습 쪽, 마지막 쪽을 먼저 보고 나머지는 훑는다.
7. **마무리**: 학생 폴더에는 STUDY.md(원본), HTML, PDF만 남긴다. 미리보기는 스크래치 폴더에 둔다.

## STUDY.md → 컴포넌트 대응표

`scaffold.py`가 이 표대로 옮긴다. 손으로 고칠 때도 같은 표를 따른다.

| STUDY.md | 컴포넌트 |
|---|---|
| 제목, 출처 줄, 범위 주의 | `.cover`의 `.hero`(`.hero-num` 단원 번호, `h1`, `.sub`), `.meta`(범위, 출처, 검증, 복습 기록 `.log`), `.scope` |
| `0. 한 장 요약` 코드 트리 | `.cover .map` SVG. 각 노드 옆에 `p.N`을 회색 작은 글자로, 범위 밖 노드는 점선 상자 |
| `## 섹션 (p.A~B)` | `section.sec` + `.head` (`.bn` 번호, `.src` 쪽 범위, `.lede`에는 핵심 개념의 첫 문장) |
| `> **핵심**:` | 섹션의 요지면 `.lede`. 아니면 본문 `<p>`에 run-in `<span class="tag link">핵심</span>`. 외울 식이면 `.formula` |
| 함수 원형과 반환값 | `.sig` (`pre` + `dl.ret`, 상수가 있으면 `.kv3`) |
| 비교표, 옵션표 | `table.bt` (`.k`, `.m`, `.hot`, `●` 열) |
| 핵심 공식, 외울 식 | `.formula` (섹션당 하나) |
| 메모리, 구조, 흐름 ASCII 그림 | `figure` + SVG |
| 예제 코드와 줄별 설명 | `pre.anno` + `ol.notes` |
| 셸 명령 | `pre.term` |
| `` ```out `` 실행 결과 | 라벨 `tag ok 실행 결과` + `pre.out` |
| `> **주의**:` | 날개 `tag warn` |
| `> **참고**:` (학생 질문) | 날개 `tag link` (날짜 라벨) |
| `(보충: …)`, `(미검증)` | 날개 `tag add` |
| `[시험범위 아님]` 섹션 | 섹션 머리 날개의 `.src` 아래 `<span class="oos">시험범위 아님</span>`(한 번만). 표지 맵은 점선 상자, 차례 `.s`에 "범위 밖" |
| 공식·명령어 모음 | `table.bt` 여러 개와 `.kv3` |
| `실습 자료 현황` 표 | `table.bt`: 항목 `.k`, 원본 쪽 `.m`, 상태 열. 미완성·오류만 `.hot` |
| `복습 질문` 표 | `table.qa` (왼쪽 질문 명조, 오른쪽 정답 고딕, 접는 선) |
| `생각 N` 카드, `[[예측]]`, `> **힌트**:`, `[[정답]]` | `.card`: 번호는 날개(`.card-no`), `.ask`(짧은 질문은 한 줄에 나란히), `.write`(두 줄), `.hint`, `.cut`, `.answer`. 카드 메모(유형, 연결, 환경)는 카드 안 `<aside class="rail">` |
| `[토론형]` 카드 | 같은 `.card`. 번호 아래 `<small>토론형</small>`, `.cut` 머리말은 `판단 기준`, `.verdict`에는 판정이 아니라 기준 한 문장, 그 아래 `table.bt` |

### 정답 부록 모드

학생이 인쇄본에서 정답을 가리고 싶어 하면 카드 안에 `.cut`과 `.answer`를 넣지 않는다. 카드 끝에 `<p class="answer-ref">정답: 부록 A.N</p>`을 두고, 맨 뒤 `section.sec.page-break.appendix`에 카드 순서대로 `<div class="answer">`를 모은다. 부록은 떼어 내 따로 쓰도록 새 쪽에서 시작한다.

### 영어 출력

`<html lang="en">`이면 그림·표 캡션이 `Figure 6.1`, `Table 6.1`로 바뀐다. 날개 머리말과 표지 라벨은 HTML에 영어로 쓴다(`scaffold.py --lang en`이 해 준다).

## 렌더 점검표

- [ ] `대조:` 경고가 없다 (카드 수, 복습 질문 수, 쪽 번호와 범위, 실행 결과)
- [ ] "차례: 쪽 번호가 실제와 맞다"가 나온다
- [ ] `쪽 끝 제목:` 경고가 없다
- [ ] `TODO:` 경고가 없다 (초안 그대로인 그림·표지가 없다)
- [ ] 글꼴이 Pretendard / JetBrains Mono / Noto Serif KR뿐이다 (대체 글꼴이 있으면 SVG의 font-family나 기호를 고친다)
- [ ] 절반 넘게 빈 쪽이 없다 (마지막 쪽과 정답 부록 앞쪽은 예외). 있으면 앞 블록을 줄이거나 그림을 작게 그린다
- [ ] 카드, 표의 행, 그림, 코드가 쪽 경계에서 잘리지 않았다
- [ ] 날개 메모가 해당 본문 옆에 있다
- [ ] SVG 글자가 상자 밖으로 나가거나 겹치지 않았다. 코드 줄이 잘리지 않았다
- [ ] 시험범위 밖 내용이 표지 맵, 차례, 섹션 머리 세 곳에서 모두 구분된다
- [ ] 정답 부록 모드라면 카드 안에 `.answer`가 하나도 없다
- [ ] 꼬리말은 2쪽부터 나온다 (표지에는 일부러 없다)

## 환경

- Edge, Chrome, Chromium 중 하나가 필요하다. Playwright가 받아 둔 Chromium(`PLAYWRIGHT_BROWSERS_PATH`, `~/.cache/ms-playwright` 등)도 자동으로 찾는다. 못 찾으면 `STUDY_BROWSER` 환경변수에 실행 파일 경로를 넣는다. Chrome 131 이상이어야 `@page` 꼬리말이 나온다.
- Linux에서 root로 실행하면 `render.py`가 `--no-sandbox`를 자동으로 붙인다. 필요하면 `STUDY_NO_SANDBOX=1`. PDF 생성이 실패하면 브라우저 오류 끝부분이 함께 표시된다.
- 점검·미리보기·차례 맞추기에는 PyMuPDF(`pip install pymupdf`)를 쓴다. 없으면 PDF만 만들고 점검은 건너뛴다.
- 글꼴은 모두 `assets/fonts`에 있어 오프라인으로 렌더된다. Noto Serif KR은 현대 한글 11,172자와 라틴·문장부호만 담은 서브셋이다. 옛한글이나 한자가 들어가면 그 글자만 고딕으로 찍힌다(렌더러가 대체 글꼴로 알려 준다).
- 흑백 인쇄용이면 `pre.term`을 밝은 `pre`로 바꿔 토너를 아낀다.
