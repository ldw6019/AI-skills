#!/usr/bin/env python3
"""study-sheet-design 렌더러: 컴포넌트 HTML -> PDF + 페이지 미리보기 + 점검.

사용법:
  python render.py page.html                      # page.pdf 생성, 미리보기는 임시 폴더
  python render.py page.html -o out.pdf --preview ./preview --keep-html
  python render.py page.html --footer "06 · C Standard File I/O"

- study.css와 글꼴(assets/)을 자동으로 넣는다. 원본 HTML에는 CSS 링크가 필요 없다.
- 꼬리말은 --footer 또는 원본의 <meta name="footer" content="...">에서 가져온다.
- Chromium 계열(Edge/Chrome/Chromium) 헤드리스 인쇄를 쓴다. 경로는 STUDY_BROWSER로 바꿀 수 있다.
- PyMuPDF(fitz)가 있으면 페이지 수, 대체 글꼴, 거의 빈 페이지를 점검하고 PNG 미리보기를 만든다.
"""
import argparse
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

SKILL = pathlib.Path(__file__).resolve().parent.parent
ASSETS = SKILL / "assets"
EXPECTED_FONTS = ("Pretendard", "JetBrainsMono")

BROWSER_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
]
BROWSER_NAMES = ["google-chrome", "chromium", "chromium-browser", "microsoft-edge", "msedge", "chrome"]


def find_browser():
    env = os.environ.get("STUDY_BROWSER")
    if env and os.path.exists(env):
        return env
    for p in BROWSER_PATHS:
        if os.path.exists(p):
            return p
    for n in BROWSER_NAMES:
        p = shutil.which(n)
        if p:
            return p
    sys.exit("Chromium 계열 브라우저를 찾지 못했다. STUDY_BROWSER 환경변수에 실행 파일 경로를 넣어라.")


def build_html(src: pathlib.Path, footer_arg):
    html = src.read_text(encoding="utf-8")
    css = (ASSETS / "study.css").read_text(encoding="utf-8")
    css = css.replace("url(fonts/", "url(" + (ASSETS / "fonts").as_uri() + "/")
    m = re.search(r'<meta\s+name="footer"\s+content="([^"]*)"', html)
    footer = footer_arg if footer_arg is not None else (m.group(1) if m else "")
    css = css.replace("__FOOTER__", footer.replace("\\", "\\\\").replace('"', '\\"'))
    html = re.sub(r"<link[^>]+study\.css[^>]*>", "", html)
    style = "<style>\n" + css + "\n</style>\n"
    if "</head>" in html:
        return html.replace("</head>", style + "</head>", 1)
    return style + html


def print_pdf(browser, html_path: pathlib.Path, pdf_path: pathlib.Path):
    cmd = [
        browser, "--headless=new", "--disable-gpu", "--no-pdf-header-footer",
        "--print-to-pdf-no-header", "--virtual-time-budget=10000",
        "--print-to-pdf=" + str(pdf_path), html_path.as_uri(),
    ]
    if pdf_path.exists():
        pdf_path.unlink()
    subprocess.run(cmd, capture_output=True, timeout=180)
    if not pdf_path.exists():
        sys.exit("PDF 생성 실패: " + " ".join(cmd))


def inspect(pdf_path: pathlib.Path, preview_dir: pathlib.Path, dpi: int):
    try:
        import pymupdf as fitz
    except ImportError:
        try:
            import fitz
        except ImportError:
            print("점검 생략: PyMuPDF가 없다 (pip install pymupdf). PDF를 직접 열어 확인할 것.")
            return
    doc = fitz.open(str(pdf_path))
    preview_dir.mkdir(parents=True, exist_ok=True)
    fallback = {}
    print(f"페이지: {doc.page_count}")
    for i, page in enumerate(doc, 1):
        out = preview_dir / f"page-{i:02d}.png"
        page.get_pixmap(dpi=dpi).save(str(out))
        lines = [l for l in page.get_text().splitlines() if l.strip()]
        body = [l for l in lines if not re.fullmatch(r"\d+ / \d+", l.strip())]
        note = ""
        if i not in (1, doc.page_count) and len(body) < 10:
            note = "  <- 거의 빈 페이지: 카드나 블록이 다음 쪽으로 밀렸는지 확인"
        print(f"  {out}{note}")
        for b in page.get_text("rawdict")["blocks"]:
            for l in b.get("lines", []):
                for sp in l["spans"]:
                    name = sp["font"].split("+")[-1]
                    if name and not name.startswith(EXPECTED_FONTS):
                        chars = "".join(c["c"] for c in sp["chars"])
                        fallback.setdefault(name, set()).add((i, chars[:20]))
    if fallback:
        print("대체 글꼴 사용 (SVG font-family에 Pretendard를 넣거나 기호를 바꿀 것):")
        for name, items in fallback.items():
            for pg, txt in sorted(items)[:8]:
                print(f"  {name}  p.{pg}  {txt!r}")
    else:
        print("글꼴: Pretendard / JetBrains Mono만 사용")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("html")
    ap.add_argument("-o", "--out")
    ap.add_argument("--footer")
    ap.add_argument("--preview", help="미리보기 PNG 폴더 (기본: 임시 폴더)")
    ap.add_argument("--dpi", type=int, default=100)
    ap.add_argument("--keep-html", action="store_true", help="CSS와 글꼴 경로가 들어간 완성 HTML을 남긴다")
    a = ap.parse_args()

    src = pathlib.Path(a.html).resolve()
    pdf = pathlib.Path(a.out).resolve() if a.out else src.with_suffix(".pdf")
    built = src.with_name(("" if a.keep_html else ".") + src.stem + ".built.html")
    built.write_text(build_html(src, a.footer), encoding="utf-8")
    try:
        print_pdf(find_browser(), built, pdf)
    finally:
        if not a.keep_html and built.exists():
            built.unlink()
    print(f"PDF: {pdf}")
    preview = pathlib.Path(a.preview).resolve() if a.preview else pathlib.Path(tempfile.gettempdir()) / f"{src.stem}_preview"
    inspect(pdf, preview, a.dpi)


if __name__ == "__main__":
    main()
