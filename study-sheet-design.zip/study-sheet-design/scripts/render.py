#!/usr/bin/env python3
"""study-sheet-design 렌더러: 컴포넌트 HTML -> PDF + 페이지 미리보기 + 점검.

사용법:
  python render.py page.html                      # page.pdf 생성, 미리보기는 임시 폴더
  python render.py page.html -o out.pdf --preview ./preview --keep-html
  python render.py page.html --footer "06 · C Standard File I/O"
  python render.py page.html --source STUDY.md     # STUDY.md와 카드·질문 수, 쪽 번호 대조
  python render.py --check                         # 브라우저만 찾아 보고 끝낸다

- study.css와 글꼴(assets/)을 자동으로 넣는다. 원본 HTML에는 CSS 링크가 필요 없다.
- 꼬리말은 --footer 또는 원본의 <meta name="footer" content="...">에서 가져온다.
- Chromium 계열(Edge/Chrome/Chromium) 헤드리스 인쇄를 쓴다. 경로는 STUDY_BROWSER로 바꿀 수 있다.
- PyMuPDF(fitz)가 있으면 페이지 수, 대체 글꼴, 거의 빈 페이지를 점검하고 PNG 미리보기를 만든다.
"""
import argparse
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

SKILL = pathlib.Path(__file__).resolve().parent.parent
ASSETS = SKILL / "assets"
EXPECTED_FONTS = ("Pretendard", "JetBrainsMono")

BROWSER_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
]
BROWSER_NAMES = ["google-chrome", "chromium", "chromium-browser", "microsoft-edge", "msedge", "chrome"]


def find_browser():
    env = os.environ.get("STUDY_BROWSER")
    if env and os.path.exists(env):
        return env
    for p in BROWSER_PATHS:
        if os.path.exists(p):
            return p
    for n in BROWSER_NAMES:
        p = shutil.which(n)
        if p:
            return p
    sys.exit("Chromium 계열 브라우저를 찾지 못했다. STUDY_BROWSER 환경변수에 실행 파일 경로를 넣어라.")


def build_html(src: pathlib.Path, footer_arg):
    html = src.read_text(encoding="utf-8")
    css = (ASSETS / "study.css").read_text(encoding="utf-8")
    css = css.replace("url(fonts/", "url(" + (ASSETS / "fonts").as_uri() + "/")
    m = re.search(r'<meta\s+name="footer"\s+content="([^"]*)"', html)
    footer = footer_arg if footer_arg is not None else (m.group(1) if m else "")
    css = css.replace("__FOOTER__", footer.replace("\\", "\\\\").replace('"', '\\"'))
    html = re.sub(r"<link[^>]+study\.css[^>]*>", "", html)
    style = "<style>\n" + css + "\n</style>\n"
    if "</head>" in html:
        return html.replace("</head>", style + "</head>", 1)
    return style + html


def needs_no_sandbox():
    # Linux에서 root로 돌리면 Chromium 샌드박스가 시작되지 않는다
    if os.environ.get("STUDY_NO_SANDBOX"):
        return True
    return sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0


def print_pdf(browser, html_path: pathlib.Path, pdf_path: pathlib.Path):
    cmd = [
        browser, "--headless=new", "--disable-gpu", "--no-pdf-header-footer",
        "--print-to-pdf-no-header", "--virtual-time-budget=10000",
        "--print-to-pdf=" + str(pdf_path), html_path.as_uri(),
    ]
    if needs_no_sandbox():
        cmd.insert(1, "--no-sandbox")
    if pdf_path.exists():
        pdf_path.unlink()
    res = subprocess.run(cmd, capture_output=True, timeout=180)
    if not pdf_path.exists():
        err = (res.stderr or b"").decode("utf-8", "replace").strip().splitlines()[-8:]
        sys.exit("PDF 생성 실패: " + " ".join(cmd) + ("\n브라우저 오류 끝부분:\n  " + "\n  ".join(err) if err else ""))


# ── STUDY.md 대조 ───────────────────────────────
PAGE_REF = re.compile(r"(?<![A-Za-z0-9_])p\.\s?(\d+)(?:\s?[~–\-]\s?(\d+))?")


def page_numbers(text):
    nums = set()
    for a, b in PAGE_REF.findall(text):
        nums.add(int(a))
        if b:
            nums.add(int(b))
    return nums


def study_counts(md):
    md = re.sub(r"^(```|~~~).*?^\1\s*$", "", md, flags=re.S | re.M)  # 코드 블록 제외
    cards = len(re.findall(r"^###\s+(?:생각|Think)\s*\d+", md, flags=re.M))
    m = re.search(r"^##\s+[^\n]*(?:복습|Review)[^\n]*\n(.*?)(?=^##\s|\Z)", md, flags=re.S | re.M)
    rows = 0
    if m:
        lines = [l for l in m.group(1).splitlines() if l.strip().startswith("|")]
        body = [l for l in lines if not re.fullmatch(r"\|[\s:|-]+\|?", l.strip())]
        rows = max(len(body) - 1, 0)  # 머리글 행 제외
    return cards, rows


def cross_check(html, study_path: pathlib.Path):
    md = study_path.read_text(encoding="utf-8")
    s_cards, s_rows = study_counts(md)
    h_cards = len(re.findall(r'<article\s+class="card', html))
    h_rows = len(re.findall(r'<td\s+class="q"', html))
    text = re.sub(r"<(script|style)\b.*?</\1>", "", html, flags=re.S)
    text = re.sub(r"<[^>]+>", " ", text)
    extra = sorted(page_numbers(text) - page_numbers(md))
    warns = []
    if h_cards != s_cards:
        warns.append(f"생각 카드 수가 다르다: STUDY.md {s_cards}개, HTML {h_cards}개")
    if h_rows != s_rows:
        warns.append(f"복습 질문 수가 다르다: STUDY.md {s_rows}행, HTML {h_rows}행")
    if extra:
        warns.append("STUDY.md에 없는 쪽 번호: " + ", ".join(f"p.{n}" for n in extra))
    print(f"대조: 카드 {h_cards}/{s_cards}, 복습 {h_rows}/{s_rows} (HTML/STUDY.md)")
    for w in warns:
        print("대조:", w)
    if not warns:
        print("대조: 차이 없음")
    return warns


def inspect(pdf_path: pathlib.Path, preview_dir: pathlib.Path, dpi: int):
    try:
        import pymupdf as fitz
    except ImportError:
        try:
            import fitz
        except ImportError:
            print("점검 생략: PyMuPDF가 없다 (pip install pymupdf). PDF를 직접 열어 확인할 것.")
            return
    doc = fitz.open(str(pdf_path))
    preview_dir.mkdir(parents=True, exist_ok=True)
    fallback = {}
    print(f"페이지: {doc.page_count}")
    for i, page in enumerate(doc, 1):
        out = preview_dir / f"page-{i:02d}.png"
        page.get_pixmap(dpi=dpi).save(str(out))
        lines = [l for l in page.get_text().splitlines() if l.strip()]
        body = [l for l in lines if not re.fullmatch(r"\d+ / \d+", l.strip())]
        note = ""
        if i not in (1, doc.page_count) and len(body) < 10:
            note = "  <- 거의 빈 페이지: 카드나 블록이 다음 쪽으로 밀렸는지 확인"
        print(f"  {out}{note}")
        for b in page.get_text("rawdict")["blocks"]:
            for l in b.get("lines", []):
                for sp in l["spans"]:
                    name = sp["font"].split("+")[-1]
                    if name and not name.startswith(EXPECTED_FONTS):
                        chars = "".join(c["c"] for c in sp["chars"])
                        fallback.setdefault(name, set()).add((i, chars[:20]))
    if fallback:
        print("대체 글꼴 사용 (SVG font-family에 Pretendard를 넣거나 기호를 바꿀 것):")
        for name, items in fallback.items():
            for pg, txt in sorted(items)[:8]:
                print(f"  {name}  p.{pg}  {txt!r}")
    else:
        print("글꼴: Pretendard / JetBrains Mono만 사용")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("html", nargs="?")
    ap.add_argument("-o", "--out")
    ap.add_argument("--footer")
    ap.add_argument("--preview", help="미리보기 PNG 폴더 (기본: 임시 폴더)")
    ap.add_argument("--dpi", type=int, default=100)
    ap.add_argument("--keep-html", action="store_true", help="CSS와 글꼴 경로가 들어간 완성 HTML을 남긴다")
    ap.add_argument("--check", action="store_true", help="브라우저를 찾아 경로만 출력하고 끝낸다 (못 찾으면 종료 코드 1)")
    ap.add_argument("--source", help="대조할 STUDY.md: 카드 수, 복습 질문 수, 원본에 없는 쪽 번호를 확인한다")
    a = ap.parse_args()

    if a.check:
        print(find_browser())
        return
    if not a.html:
        ap.error("HTML 파일을 지정하라 (또는 --check)")

    src = pathlib.Path(a.html).resolve()
    if a.source:
        cross_check(src.read_text(encoding="utf-8"), pathlib.Path(a.source))
    pdf = pathlib.Path(a.out).resolve() if a.out else src.with_suffix(".pdf")
    built = src.with_name(("" if a.keep_html else ".") + src.stem + ".built.html")
    built.write_text(build_html(src, a.footer), encoding="utf-8")
    try:
        print_pdf(find_browser(), built, pdf)
    finally:
        if not a.keep_html and built.exists():
            built.unlink()
    print(f"PDF: {pdf}")
    preview = pathlib.Path(a.preview).resolve() if a.preview else pathlib.Path(tempfile.gettempdir()) / f"{src.stem}_preview"
    inspect(pdf, preview, a.dpi)


if __name__ == "__main__":
    main()
