#!/usr/bin/env python3
"""study-sheet-design 렌더러: 컴포넌트 HTML -> PDF + 페이지 미리보기 + 점검.

사용법:
  python render.py page.html                      # page.pdf 생성, 미리보기는 임시 폴더
  python render.py page.html -o out.pdf --preview ./preview --keep-html
  python render.py page.html --footer "06 · C Standard File I/O"
  python render.py page.html --source STUDY.md     # STUDY.md와 카드·질문 수, 쪽 번호 대조
  python render.py --check                         # 브라우저만 찾아 보고 끝낸다
  python render.py --pdf out.pdf                   # 이미 있는 PDF만 점검 (대비 등)
  python render.py page.html --fix-toc             # 차례 쪽 번호를 실제 쪽으로 고친다

- study.css와 글꼴(assets/)을 자동으로 넣는다. 원본 HTML에는 CSS 링크가 필요 없다.
- 꼬리말은 --footer 또는 원본의 <meta name="footer" content="...">에서 가져온다.
- Chromium 계열(Edge/Chrome/Chromium) 헤드리스 인쇄를 쓴다. 경로는 STUDY_BROWSER로 바꿀 수 있다.
- PyMuPDF(fitz)가 있으면 페이지 수, 대체 글꼴, 거의 빈 페이지를 점검하고 PNG 미리보기를 만든다.
"""
import argparse
import html as htmlmod
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

SKILL = pathlib.Path(__file__).resolve().parent.parent
ASSETS = SKILL / "assets"
EXPECTED_FONTS = ("Pretendard", "JetBrainsMono", "NotoSerifKR")

BROWSER_PATHS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
]
BROWSER_NAMES = ["google-chrome", "chromium", "chromium-browser", "microsoft-edge", "msedge", "chrome"]
# Playwright가 받아 둔 Chromium (클라우드·CI 환경에서 흔하다)
PW_PATTERNS = [
    "chromium-*/chrome-linux*/chrome",
    "chromium-*/chrome-win*/chrome.exe",
    "chromium-*/chrome-mac*/Chromium.app/Contents/MacOS/Chromium",
    "chromium-*/chrome-mac*/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing",
]


def playwright_browsers():
    roots = []
    env = os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
    if env and env != "0":
        roots.append(pathlib.Path(env))
    home = pathlib.Path.home()
    roots += [home / ".cache" / "ms-playwright", home / "Library" / "Caches" / "ms-playwright"]
    if os.environ.get("LOCALAPPDATA"):
        roots.append(pathlib.Path(os.environ["LOCALAPPDATA"]) / "ms-playwright")
    found = []
    for r in roots:
        if r.is_dir():
            for pat in PW_PATTERNS:
                found += [p for p in r.glob(pat) if p.is_file()]

    def rev(p):  # chromium-1243 -> 1243, 새 버전 먼저
        m = re.search(r"chromium-(\d+)", str(p))
        return int(m.group(1)) if m else 0
    return [str(p) for p in sorted(found, key=rev, reverse=True)]


def find_browser():
    env = os.environ.get("STUDY_BROWSER")
    if env and os.path.exists(env):
        return env
    for p in BROWSER_PATHS:
        if os.path.exists(p):
            return p
    for n in BROWSER_NAMES:
        p = shutil.which(n)
        if p:
            return p
    pw = playwright_browsers()
    if pw:
        return pw[0]
    sys.exit("Chromium 계열 브라우저를 찾지 못했다. 다음 중 하나를 한다:\n"
             "  1) 설치: pip install playwright && python -m playwright install chromium  (설치 뒤 자동으로 찾는다)\n"
             "  2) 이미 있는 Chrome/Edge 경로를 STUDY_BROWSER 환경변수에 넣는다\n"
             "  3) 둘 다 안 되면 course-study-builder의 render_study.py로 PDF를 만든다 (단순한 모양)")


def build_html(src: pathlib.Path, footer_arg):
    html = src.read_text(encoding="utf-8")
    css = (ASSETS / "study.css").read_text(encoding="utf-8")
    css = css.replace("url(fonts/", "url(" + (ASSETS / "fonts").as_uri() + "/")
    m = re.search(r'<meta\s+name="footer"\s+content="([^"]*)"', html)
    footer = footer_arg if footer_arg is not None else (m.group(1) if m else "")
    css = css.replace("__FOOTER__", footer.replace("\\", "\\\\").replace('"', '\\"'))
    html = re.sub(r"<link[^>]+study\.css[^>]*>", "", html)
    style = "<style>\n" + css + "\n</style>\n"
    if "</head>" in html:
        return html.replace("</head>", style + "</head>", 1)
    return style + html


def needs_no_sandbox():
    # Linux에서 root로 돌리면 Chromium 샌드박스가 시작되지 않는다
    if os.environ.get("STUDY_NO_SANDBOX"):
        return True
    return sys.platform.startswith("linux") and hasattr(os, "geteuid") and os.geteuid() == 0


def print_pdf(browser, html_path: pathlib.Path, pdf_path: pathlib.Path):
    cmd = [
        browser, "--headless=new", "--disable-gpu", "--no-pdf-header-footer",
        "--print-to-pdf-no-header", "--virtual-time-budget=10000",
        "--print-to-pdf=" + str(pdf_path), html_path.as_uri(),
    ]
    if needs_no_sandbox():
        cmd.insert(1, "--no-sandbox")
    if pdf_path.exists():
        pdf_path.unlink()
    res = subprocess.run(cmd, capture_output=True, timeout=180)
    if not pdf_path.exists():
        err = (res.stderr or b"").decode("utf-8", "replace").strip().splitlines()[-8:]
        sys.exit("PDF 생성 실패: " + " ".join(cmd) + ("\n브라우저 오류 끝부분:\n  " + "\n  ".join(err) if err else ""))


# ── STUDY.md 대조 ───────────────────────────────
PAGE_REF = re.compile(r"(?<![A-Za-z0-9_])p\.\s?(\d+)(?:\s?[~–\-]\s?(\d+))?")


def page_numbers(text):
    nums = set()
    for a, b in PAGE_REF.findall(text):
        nums.add(int(a))
        if b:
            nums.add(int(b))
    return nums


def page_ranges(text):
    return {(int(a), int(b)) for a, b in PAGE_REF.findall(text) if b and int(a) != int(b)}


def norm_line(s):
    # 줄 끝 공백만 무시한다. 출력의 들여쓰기와 칸 맞춤은 내용이다
    return s.expandtabs(8).rstrip()


def study_out_lines(md):
    lines = set()
    for block in re.findall(r"^```out[ \t]*\n(.*?)^```", md, flags=re.S | re.M):
        lines |= {norm_line(l) for l in block.splitlines() if l.strip()}
    return lines


def html_out_lines(html):
    out = []
    for block in re.findall(r'<pre\s+class="out"[^>]*>(.*?)</pre>', html, flags=re.S):
        text = htmlmod.unescape(re.sub(r"<[^>]+>", "", block))
        out += [norm_line(l) for l in text.splitlines() if l.strip()]
    return out


def study_counts(md):
    md = re.sub(r"^(```|~~~).*?^\1\s*$", "", md, flags=re.S | re.M)  # 코드 블록 제외
    cards = len(re.findall(r"^###\s+(?:생각|Think)\s*\d+", md, flags=re.M))
    m = re.search(r"^##\s+[^\n]*(?:복습|Review)[^\n]*\n(.*?)(?=^##\s|\Z)", md, flags=re.S | re.M)
    rows = 0
    if m:
        lines = [l for l in m.group(1).splitlines() if l.strip().startswith("|")]
        body = [l for l in lines if not re.fullmatch(r"\|[\s:|-]+\|?", l.strip())]
        rows = max(len(body) - 1, 0)  # 머리글 행 제외
    return cards, rows


def cross_check(html, study_path: pathlib.Path):
    md = study_path.read_text(encoding="utf-8")
    s_cards, s_rows = study_counts(md)
    h_cards = len(re.findall(r'<article\s+class="card', html))
    h_rows = len(re.findall(r'<td\s+class="q"', html))
    text = re.sub(r"<(script|style)\b.*?</\1>", "", html, flags=re.S)
    text = re.sub(r"<[^>]+>", " ", text)
    text = htmlmod.unescape(text)
    extra = sorted(page_numbers(text) - page_numbers(md))
    extra_ranges = sorted(page_ranges(text) - page_ranges(md))
    s_out = study_out_lines(md)
    bad_out = [l for l in html_out_lines(html) if l not in s_out]
    warns = []
    if h_cards != s_cards:
        warns.append(f"생각 카드 수가 다르다: STUDY.md {s_cards}개, HTML {h_cards}개")
    if h_rows != s_rows:
        warns.append(f"복습 질문 수가 다르다: STUDY.md {s_rows}행, HTML {h_rows}행")
    if extra:
        warns.append("STUDY.md에 없는 쪽 번호: " + ", ".join(f"p.{n}" for n in extra))
    if extra_ranges:
        warns.append("STUDY.md에 없는 쪽 범위 (원본 범위를 그대로 쓰거나 비워 둔다): "
                     + ", ".join(f"p.{a}–{b}" for a, b in extra_ranges))
    if bad_out:
        shown = bad_out[:5]
        warns.append("STUDY.md의 실행 결과(```out)에 없는 줄 %d개: " % len(bad_out)
                     + " | ".join(repr(l) for l in shown) + (" …" if len(bad_out) > 5 else ""))
    print(f"대조: 카드 {h_cards}/{s_cards}, 복습 {h_rows}/{s_rows} (HTML/STUDY.md)")
    for w in warns:
        print("대조:", w)
    if not warns:
        print("대조: 차이 없음")
    return warns



# ── 글자 대비 ───────────────────────────────
def _lum(rgb):
    def ch(c):
        c = c / 255
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (ch(c) for c in rgb)
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def contrast(a, b):
    la, lb = _lum(a), _lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def contrast_issues(page, pix, scale):
    """쪽의 글자마다 글자색과 실제 바탕색(렌더된 픽셀)의 대비를 잰다.
    기준: WCAG AA. 본문 4.5:1, 큰 글자(18pt 이상 또는 14pt 이상 굵은 글자) 3:1."""
    out = []
    W, H, n = pix.width, pix.height, pix.n
    data = pix.samples
    for b in page.get_text("dict")["blocks"]:
        for l in b.get("lines", []):
            for sp in l["spans"]:
                text = sp["text"].strip()
                if not text:
                    continue
                c = sp["color"]
                fg = ((c >> 16) & 255, (c >> 8) & 255, c & 255)
                x0, y0, x1, y1 = (int(v * scale) for v in sp["bbox"])
                x0, y0 = max(x0 - 2, 0), max(y0 - 2, 0)
                x1, y1 = min(x1 + 2, W - 1), min(y1 + 2, H - 1)
                counts = {}
                # 글자 상자 테두리 1px 띠에서 바탕색을 고른다 (글자 획은 피하고 가장 흔한 색)
                ring = [(x, y0) for x in range(x0, x1)] + [(x, y1) for x in range(x0, x1)] + \
                       [(x0, y) for y in range(y0, y1)] + [(x1, y) for y in range(y0, y1)]
                for x, y in ring:
                    i = (y * W + x) * n
                    px = tuple(data[i:i + 3])
                    if contrast(px, fg) < 1.15:
                        continue
                    counts[px] = counts.get(px, 0) + 1
                if not counts:
                    continue
                bg = max(counts, key=counts.get)
                ratio = contrast(fg, bg)
                bold = "Bold" in sp["font"] or "Semi" in sp["font"] or bool(sp["flags"] & 16)
                large = sp["size"] >= 18 or (bold and sp["size"] >= 14)  # PDF 글자 크기는 pt
                need = 3.0 if large else 4.5
                if ratio < need:
                    out.append((ratio, need, text[:24], "#%02x%02x%02x" % fg, "#%02x%02x%02x" % bg))
    return out


def inspect(pdf_path: pathlib.Path, preview_dir: pathlib.Path, dpi: int):
    fitz = load_fitz()
    if not fitz:
        print("점검 생략: PyMuPDF가 없다 (pip install pymupdf). PDF를 직접 열어 확인할 것.")
        return
    doc = fitz.open(str(pdf_path))
    preview_dir.mkdir(parents=True, exist_ok=True)
    fallback, low = {}, []
    print(f"페이지: {doc.page_count}")
    for i, page in enumerate(doc, 1):
        out = preview_dir / f"page-{i:02d}.png"
        pix = page.get_pixmap(dpi=dpi)
        pix.save(str(out))
        for ratio, need, txt, fg, bg in contrast_issues(page, pix, dpi / 72):
            low.append((i, ratio, need, txt, fg, bg))
        lines = [l for l in page.get_text().splitlines() if l.strip()]
        body = [l for l in lines if not re.fullmatch(r"\d+ / \d+", l.strip())]
        note = ""
        if i not in (1, doc.page_count) and len(body) < 10:
            note = "  <- 거의 빈 페이지: 카드나 블록이 다음 쪽으로 밀렸는지 확인"
        print(f"  {out}{note}")
        for b in page.get_text("rawdict")["blocks"]:
            for l in b.get("lines", []):
                for sp in l["spans"]:
                    name = sp["font"].split("+")[-1]
                    if name and not name.startswith(EXPECTED_FONTS):
                        chars = "".join(c["c"] for c in sp["chars"])
                        fallback.setdefault(name, set()).add((i, chars[:20]))
    if low:
        print(f"대비 부족: 글자 {len(low)}곳이 바탕과 구분이 약하다 (WCAG AA 기준). 글자색이나 바탕색을 바꿀 것:")
        for pg, ratio, need, txt, fg, bg in low[:20]:
            print(f"  p.{pg}  {ratio:.1f}:1 (필요 {need:.1f})  글자 {fg} / 바탕 {bg}  {txt!r}")
    else:
        print("대비: 모든 글자가 WCAG AA 기준을 넘는다")
    if fallback:
        print("대체 글꼴 사용 (SVG font-family에 Pretendard를 넣거나 기호를 바꿀 것):")
        for name, items in fallback.items():
            for pg, txt in sorted(items)[:8]:
                print(f"  {name}  p.{pg}  {txt!r}")
    else:
        print("글꼴: Pretendard / JetBrains Mono / Noto Serif KR만 사용")


def load_fitz():
    try:
        import pymupdf as fitz
        return fitz
    except ImportError:
        try:
            import fitz
            return fitz
        except ImportError:
            return None


# ── 차례 쪽 번호 ───────────────────────────────
TOC_ITEM = re.compile(r'(<a\s+href="#([\w-]+)"[^>]*>.*?<span\s+class="p">)(.*?)(</span>\s*</a>)', re.S)


def squash(t):
    return re.sub(r"\s+", "", htmlmod.unescape(re.sub(r"<[^>]+>", "", t)))


def toc_pages(html, pdf_path: pathlib.Path):
    """차례 항목마다 (id, 차례에 적힌 값, 실제 쪽)을 돌려준다. PyMuPDF가 없으면 None."""
    fitz = load_fitz()
    if not fitz:
        return None
    nav = re.search(r'<nav\s+class="toc".*?</nav>', html, re.S)
    if not nav:
        return []
    doc = fitz.open(str(pdf_path))
    # 1순위: Chrome이 PDF에 남긴 차례 링크. 링크마다 이동할 쪽이 정확히 들어 있다
    dest = {}
    for page in doc:
        for l in page.get_links():
            name = l.get("nameddest") or (l.get("uri") or "").lstrip("#")
            if name and l.get("page", -1) is not None and l.get("page", -1) >= 0:
                dest.setdefault(name, l["page"] + 1)
    # 2순위: 링크가 없으면 표지 다음 쪽부터 섹션 제목을 차례 순서대로 찾는다
    texts = [squash(p.get_text()) for p in doc]
    starts, pos = [], 0
    for t in texts:
        starts.append(pos)
        pos += len(t)
    full, cursor = "".join(texts), (starts[1] if len(starts) > 1 else 0)
    rows = []
    for m in TOC_ITEM.finditer(nav.group(0)):
        sid, shown = m.group(2), m.group(3).strip()
        actual = dest.get(sid)
        if actual is None:
            sec = re.search(r'<section[^>]*\bid="%s"[^>]*>.*?<h2[^>]*>(.*?)</h2>' % re.escape(sid), html, re.S)
            key = squash(sec.group(1)) if sec else ""
            hit = full.find(key, cursor) if key else -1
            if hit >= 0:
                cursor = hit + len(key)
                actual = max(i for i, st in enumerate(starts) if st <= hit) + 1
        rows.append((sid, shown, actual))
    return rows


def fix_toc(html, rows):
    want = {sid: str(actual) for sid, shown, actual in rows if actual and shown != str(actual)}

    def rep(m):
        return m.group(1) + want[m.group(2)] + m.group(4) if m.group(2) in want else m.group(0)
    nav = re.search(r'<nav\s+class="toc".*?</nav>', html, re.S)
    return html[:nav.start()] + TOC_ITEM.sub(rep, nav.group(0)) + html[nav.end():]


def orphan_heads(pdf_path: pathlib.Path):
    """섹션 제목(명조 15~19pt)이 쪽 끝에 홀로 남았는지 본다. 제목 아래에 리드 한두 줄밖에 없으면 경고."""
    fitz = load_fitz()
    if not fitz:
        return []
    bad = []
    doc = fitz.open(str(pdf_path))
    for i, page in enumerate(doc, 1):
        limit = page.rect.height - 15 * 72 / 25.4          # 꼬리말 영역 제외
        allspans, heads = [], []
        for b in page.get_text("dict")["blocks"]:
            for l in b.get("lines", []):
                for sp in l["spans"]:
                    if not sp["text"].strip() or sp["bbox"][3] > limit:
                        continue
                    allspans.append(sp)
                    if "Serif" in sp["font"] and 15 <= sp["size"] <= 19:
                        heads.append(sp)
        for h in heads:
            # 본문 칸(제목과 같은 왼쪽 선)에 있는 글자만 본다. 날개 메모는 세지 않는다
            below = [sp["bbox"][3] for sp in allspans if sp["bbox"][0] >= h["bbox"][0] - 2]
            if (max(below) - h["bbox"][3] < 40 and h["bbox"][1] > page.rect.height * 0.55
                    and i < doc.page_count):
                bad.append((i, h["text"].strip()))
    return bad


def render_once(src, pdf, a):
    built = src.with_name(("" if a.keep_html else ".") + src.stem + ".built.html")
    built.write_text(build_html(src, a.footer), encoding="utf-8")
    try:
        print_pdf(find_browser(), built, pdf)
    finally:
        if not a.keep_html and built.exists():
            built.unlink()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("html", nargs="?")
    ap.add_argument("-o", "--out")
    ap.add_argument("--footer")
    ap.add_argument("--preview", help="미리보기 PNG 폴더 (기본: 임시 폴더)")
    ap.add_argument("--dpi", type=int, default=100)
    ap.add_argument("--keep-html", action="store_true", help="CSS와 글꼴 경로가 들어간 완성 HTML을 남긴다")
    ap.add_argument("--check", action="store_true", help="브라우저를 찾아 경로만 출력하고 끝낸다 (못 찾으면 종료 코드 1)")
    ap.add_argument("--source", help="대조할 STUDY.md: 카드 수, 복습 질문 수, 쪽 번호·범위, 실행 결과를 확인한다")
    ap.add_argument("--pdf", help="이미 있는 PDF만 점검한다 (대비, 글꼴, 빈 쪽, 쪽 끝 제목). Markdown 경로의 PDF에도 쓴다")
    ap.add_argument("--fix-toc", action="store_true", help="차례의 쪽 번호를 실제 쪽으로 고쳐 원본 HTML에 쓰고 다시 렌더한다")
    a = ap.parse_args()

    if a.check:
        print(find_browser())
        return
    if a.pdf:
        pdf = pathlib.Path(a.pdf).resolve()
        for pg, title in orphan_heads(pdf):
            print(f"쪽 끝 제목: {pg}쪽 '{title}' 아래에 본문이 없다")
        preview = pathlib.Path(a.preview).resolve() if a.preview else pathlib.Path(tempfile.gettempdir()) / f"{pdf.stem}_preview"
        inspect(pdf, preview, a.dpi)
        return
    if not a.html:
        ap.error("HTML 파일을 지정하라 (또는 --check)")

    src = pathlib.Path(a.html).resolve()
    if a.source:
        cross_check(src.read_text(encoding="utf-8"), pathlib.Path(a.source))
    pdf = pathlib.Path(a.out).resolve() if a.out else src.with_suffix(".pdf")
    render_once(src, pdf, a)
    rows = toc_pages(src.read_text(encoding="utf-8"), pdf)
    for _ in range(3):  # 쪽 번호를 고치면 줄바꿈이 달라질 수 있어 다시 확인한다
        if not (a.fix_toc and rows and any(act and shown != str(act) for _, shown, act in rows)):
            break
        src.write_text(fix_toc(src.read_text(encoding="utf-8"), rows), encoding="utf-8")
        print("차례: 쪽 번호를 고쳐 다시 렌더한다")
        render_once(src, pdf, a)
        rows = toc_pages(src.read_text(encoding="utf-8"), pdf)
    print(f"PDF: {pdf}")
    todo = src.read_text(encoding="utf-8").count("<!-- TODO")
    if todo:
        print(f"TODO: 다듬을 곳 {todo}개가 남았다 (HTML에서 <!-- TODO 검색)")
    if rows is None:
        print("차례 점검 생략: PyMuPDF가 없다")
    elif rows:
        bad = [(sid, shown, act) for sid, shown, act in rows if not act or shown != str(act)]
        if not bad:
            print("차례: 쪽 번호가 실제와 맞다")
        for sid, shown, act in bad:
            print(f"차례: #{sid} 차례 {shown!r}, 실제 {act if act else '찾지 못함'}"
                  + ("" if a.fix_toc or not act else " (--fix-toc로 고칠 수 있다)"))
    for pg, title in orphan_heads(pdf):
        print(f"쪽 끝 제목: {pg}쪽 '{title}' 아래에 본문이 없다 (앞 블록을 줄이거나 제목 앞에 class=\"page-break\")")
    preview = pathlib.Path(a.preview).resolve() if a.preview else pathlib.Path(tempfile.gettempdir()) / f"{src.stem}_preview"
    inspect(pdf, preview, a.dpi)


if __name__ == "__main__":
    main()
