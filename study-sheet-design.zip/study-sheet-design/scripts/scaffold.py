#!/usr/bin/env python3
"""STUDY.md -> study-sheet-design HTML 뼈대.

course-study-builder가 쓴 STUDY.md를 읽어 이 스킬의 컴포넌트로 채운 HTML 초안을 만든다.
표지, 한 장 요약 맵, 차례, 섹션 머리, 레일 노트, 표, 코드, 실행 결과, 생각 카드, 복습 표,
정답 부록까지 자동으로 옮긴다. 손으로 다듬을 곳(SVG 다시 그리기, 표지 모티프, 캡션)은
<!-- TODO: ... --> 주석으로 남긴다.

쪽 번호, 실행 결과, 카드와 질문은 STUDY.md에 있는 것만 옮긴다. 새로 만들지 않는다.

사용법:
  python scaffold.py STUDY.md -o "3주차_공부자료(슬라이싱).html"
  python scaffold.py STUDY.md --answers appendix --course "시스템 프로그래밍" --term "2026-2 · 중간고사"
  python scaffold.py STUDY.md --lang en

표준 라이브러리만 쓴다.
"""
import argparse
import html
import pathlib
import re
import sys

SKILL = pathlib.Path(__file__).resolve().parent.parent

# 단원 강조색. --accent로 바꾸면 진한 색과 옅은 면은 여기서 계산한다
PAL = {}


def set_palette(accent):
    h = accent.lstrip("#")
    if not re.fullmatch(r"[0-9a-fA-F]{6}", h):
        sys.exit("--accent는 #2b44b8 같은 6자리 색이어야 한다")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))

    def mix(t, toward=255):
        return "#%02x%02x%02x" % tuple(round(c + (toward - c) * t) for c in (r, g, b))
    PAL.update(accent="#" + h.lower(), deep=mix(0.38, 0), tint=mix(0.91), tint2=mix(0.82))
SPECIMEN = SKILL / "examples" / "specimen.html"

L = {
    "ko": {
        "map": "한 장 요약", "toc": "차례", "range": "범위", "source": "출처", "verify": "검증", "content": "수록",
        "oos": "시험범위 아님", "oos_short": "범위 밖", "warn": "주의", "note": "참고", "key": "핵심", "hint": "힌트",
        "add": "보충", "unverified": "미검증", "out": "실행 결과", "predict": "내 예측", "answer": "정답",
        "criterion": "판단 기준", "discuss": "토론형", "think": "생각해 보기", "review": "복습 질문",
        "think_lede": "예측을 먼저 적고, 막히면 힌트만 본 뒤, 직접 풀고 나서 점선 아래 정답과 비교한다.",
        "think_rail": "순서: 예측 적기 → 막히면 힌트 → 직접 실행·풀이 → 정답과 비교",
        "review_lede": "자습용이며 실제 시험 문제가 아니다. 오른쪽 단을 접어 가리고 풀고, 맞힌 문항은 네모에 표시한다.",
        "fold": "정답 (여기서 접기)", "q": "질문", "cards": "카드 {n}개", "rows": "{n}문항",
        "appendix": "부록: 생각해 보기 정답", "appendix_lede": "예측을 다 적은 뒤에 펼친다.",
        "answer_ref": "정답: 부록 A.{n}", "sections": "섹션 {k}개, 카드 {n}개", "rows_small": "복습 {m}문항",
        "summary": "정리", "subject": "과목명", "log": "복습 기록", "log_items": ["당일", "1주 뒤", "시험 전"], "verify_default": "STUDY.md의 관찰값",
        "verify_small": "실행 결과는 원본 그대로",
    },
    "en": {
        "map": "One-page summary", "toc": "Contents", "range": "Scope", "source": "Sources", "verify": "Verified",
        "content": "Contents", "oos": "Out of exam scope", "oos_short": "out of scope", "warn": "Warning",
        "note": "Note", "key": "Key", "hint": "Hint", "add": "Added", "unverified": "Unverified",
        "out": "Output", "predict": "Your prediction", "answer": "Answer", "criterion": "Criterion",
        "discuss": "discussion", "think": "Think it through", "review": "Review questions",
        "think_lede": "Write a prediction, read the hint only if stuck, solve it, then compare with the answer below the dashed line.",
        "think_rail": "Order: predict → hint if stuck → run or solve → compare",
        "review_lede": "For self-study, not actual exam questions. Fold the right column, answer, then tick the box.",
        "fold": "Answer (fold here)", "q": "Question", "cards": "{n} cards", "rows": "{n} questions",
        "appendix": "Appendix: answers to the self-test", "appendix_lede": "Open only after writing every prediction.",
        "answer_ref": "Answer: appendix A.{n}", "sections": "{k} sections, {n} cards", "rows_small": "{m} review questions",
        "summary": "Summary", "subject": "Course", "log": "Review log", "log_items": ["Same day", "After a week", "Before the exam"], "verify_default": "Observed values from STUDY.md",
        "verify_small": "Outputs copied as observed",
    },
}

CALLOUT = re.compile(r"^>\s*\*\*(주의|Warning|Caution|핵심|Key|참고|Note|힌트|Hint)\*\*\s*[:：]\s*(.*)$")
KIND = {"주의": "warn", "Warning": "warn", "Caution": "warn", "핵심": "key", "Key": "key",
        "참고": "note", "Note": "note", "힌트": "hint", "Hint": "hint"}
PAGE = re.compile(r"\(p\.\s?(\d+)(?:\s?[~–-]\s?(\d+))?\)")
OOS = re.compile(r"\[(시험범위 아님|Out of exam scope)\]")
CARD = re.compile(r"^###\s+(생각|Think)\s*(\d+)\.?\s*(.*)$")
TREE_GLYPH = re.compile(r"^[\s│├└─┬┴┼|`\\+\-]*")


# ── 인라인 ─────────────────────────────────────
def inline(s):
    parts = re.split(r"(`[^`]+`)", s)
    out = []
    for p in parts:
        if p.startswith("`") and p.endswith("`") and len(p) > 1:
            out.append("<code>" + html.escape(p[1:-1]) + "</code>")
        else:
            t = html.escape(p)
            t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
            out.append(t)
    return "".join(out)


def dash(s):  # p.1~4 -> p.1–4 (표시용; 숫자는 그대로)
    return re.sub(r"(p\.\s?\d+)\s?~\s?(\d+)", r"\1–\2", s)


def page_label(text):
    m = PAGE.search(text)
    if not m:
        return ""
    return "p.%s" % m.group(1) + ("–%s" % m.group(2) if m.group(2) else "")


def strip_pages(text):
    t = PAGE.sub("", text).strip()
    return re.sub(r"\s+([.,:;!?])", r"\1", t)  # (p.4). -> . 앞 공백 정리


# ── 블록 파서 ───────────────────────────────────
def parse_blocks(lines):
    """[(kind, data)] : p, table, code(lang, text), quote(kind, text), list(ordered, items), svg, h, marker"""
    blocks, i, n = [], 0, len(lines)
    while i < n:
        line = lines[i]
        s = line.strip()
        if not s:
            i += 1
            continue
        if s.startswith("```") or s.startswith("~~~"):
            fence, lang = s[:3], s[3:].strip()
            body = []
            i += 1
            while i < n and not lines[i].strip().startswith(fence):
                body.append(lines[i])
                i += 1
            blocks.append(("code", (lang, "\n".join(body))))
            i += 1
            continue
        if s.startswith("<svg"):
            body = [line]
            while i < n and "</svg>" not in lines[i]:
                i += 1
                if i < n:
                    body.append(lines[i])
            blocks.append(("svg", "\n".join(body)))
            i += 1
            continue
        if re.fullmatch(r"\[\[/?(예측|정답|Predict|Answer)\]\]", s):
            blocks.append(("marker", s))
            i += 1
            continue
        if s.startswith("|"):
            rows = []
            while i < n and lines[i].strip().startswith("|"):
                r = lines[i].strip()
                if not re.fullmatch(r"\|[\s:|-]+\|?", r):
                    rows.append([c.strip() for c in r.strip("|").split("|")])
                i += 1
            blocks.append(("table", rows))
            continue
        if s.startswith(">"):
            q = []
            while i < n and lines[i].strip().startswith(">"):
                q.append(lines[i].strip())
                i += 1
            m = CALLOUT.match(q[0])
            rest = " ".join(x.lstrip(">").strip() for x in q[1:])
            if m:
                blocks.append(("quote", (KIND[m.group(1)], (m.group(2) + " " + rest).strip())))
            else:
                blocks.append(("quote", ("note", " ".join(x.lstrip(">").strip() for x in q))))
            continue
        if s.startswith("#"):
            blocks.append(("h", re.sub(r"^#+\s*", "", s)))
            i += 1
            continue
        m = re.match(r"^(\d+\.|-)\s+(.*)$", s)
        if m:
            ordered = m.group(1) != "-"
            items = []
            while i < n:
                mm = re.match(r"^\s*(\d+\.|-)\s+(.*)$", lines[i])
                if not mm:
                    break
                items.append(mm.group(2))
                i += 1
            blocks.append(("list", (ordered, items)))
            continue
        para = [s]
        i += 1
        while i < n and lines[i].strip() and not re.match(r"^\s*(```|~~~|\||>|#|<svg|\[\[|\d+\.\s|-\s)", lines[i]):
            para.append(lines[i].strip())
            i += 1
        blocks.append(("p", " ".join(para)))
    return blocks


def split_sections(md):
    lines = md.splitlines()
    head, secs, cur = [], [], None
    in_fence = False
    for line in lines:
        if line.strip().startswith(("```", "~~~")):
            in_fence = not in_fence
        if not in_fence and line.startswith("## "):
            cur = {"title": line[3:].strip(), "lines": []}
            secs.append(cur)
        elif cur is None:
            head.append(line)
        else:
            cur["lines"].append(line)
    return head, secs


def classify(title):
    t = title.lower()
    if re.search(r"한 장 요약|one-page summary", t):
        return "map"
    if re.search(r"복습|review", t):
        return "review"
    if re.search(r"생각해 보기|think it through", t):
        return "think"
    if re.search(r"정리|모음|cheat|summary of|formulas", t):
        return "summary"
    return "topic"


# ── 렌더 조각 ───────────────────────────────────
def is_diagram(text):
    return bool(re.search(r"[├└│┌┐┘─]|\[ \S+ \]|\+-{2,}", text))


def code_block(lang, text, lb):
    esc = html.escape(text)
    if lang == "out":
        return ('<div><div class="label"><span class="tag ok">%s</span></div>\n<pre class="out">%s</pre></div>'
                % (lb["out"], esc))
    if text.lstrip().startswith("$ "):
        body = re.sub(r"(?m)^\$ ", '<span class="pr">$</span> ', esc)
        return '<pre class="term">%s</pre>' % body
    pre = "<pre>%s</pre>" % esc
    if is_diagram(text):
        return ('<!-- TODO: ASCII 그림을 SVG figure로 다시 그린다 (reference/svg.md). 숫자·라벨은 아래 그대로 -->\n'
                + pre)
    return pre


def table_bt(rows):
    if not rows:
        return ""
    head, body = rows[0], rows[1:]
    th = "".join("<th>%s</th>" % inline(c) for c in head)
    trs = []
    for r in body:
        tds = []
        for j, c in enumerate(r):
            cls = ' class="k"' if j == 0 and re.fullmatch(r"`[^`]+`", c) else ""
            val = c[1:-1] if cls else c
            tds.append("<td%s>%s</td>" % (cls, html.escape(val) if cls else inline(val)))
        trs.append("<tr>%s</tr>" % "".join(tds))
    return '<table class="bt">\n  <thead><tr>%s</tr></thead>\n  <tbody>\n    %s\n  </tbody>\n</table>' % (
        th, "\n    ".join(trs))


def list_html(ordered, items):
    tag = "ol" if ordered else "ul"
    return "<%s>%s</%s>" % (tag, "".join("<li>%s</li>" % inline(x) for x in items), tag)


def rail(notes):
    return '<aside class="rail">%s</aside>' % "".join('<div class="note">%s</div>' % n for n in notes)


def first_sentence(text):
    m = re.match(r"^(.+?[.!?。])(\s+|$)(.*)$", text)
    if m:
        return m.group(1), m.group(3).strip()
    return text, ""


def body_items(blocks, lb, lede_taken=False):
    """섹션 본문: (rail notes 묶음, 본문 블록) 순서로 만든다. 레일은 다음 본문 블록 바로 앞에 놓인다."""
    out, pending = [], []
    lede = None
    for kind, data in blocks:
        if kind == "quote":
            k, text = data
            if k == "warn":
                pending.append('<span class="tag warn">%s</span>%s' % (lb["warn"], inline(text)))
            elif k == "note":
                pending.append('<span class="tag link">%s</span>%s' % (lb["note"], inline(text)))
            elif k == "key":
                out.append((pending, '<p><span class="tag link">%s</span>%s</p>' % (lb["key"], inline(text))))
                pending = []
            elif k == "hint":
                out.append((pending, '<p class="hint"><span class="tag">%s</span><span>%s</span></p>'
                            % (lb["hint"], inline(text))))
                pending = []
            continue
        if kind == "p":
            if lede is None and not lede_taken:
                first, rest = first_sentence(data)
                lede = inline(first)
                if not rest:
                    continue
                data = rest
            if re.search(r"\(미검증|\(unverified", data, re.I):
                pending.append('<span class="tag add">%s</span>%s' % (lb["unverified"], "원본 표시 그대로" if lb is L["ko"] else "as marked in the source"))
            if re.search(r"\(보충|\(added", data, re.I):
                pending.append('<span class="tag add">%s</span>%s' % (lb["add"], "강의자료 밖 내용" if lb is L["ko"] else "outside the lecture material"))
            html_ = "<p>%s</p>" % inline(data)
        elif kind == "table":
            html_ = "<div>\n%s\n</div>" % table_bt(data)
        elif kind == "code":
            html_ = code_block(data[0], data[1], lb)
        elif kind == "svg":
            html_ = ('<!-- TODO: 폭 540으로 다시 그리고 svg.md 팔레트·화살표를 쓴다. 아래는 STUDY.md 원본 -->\n'
                     '<figure><div class="label"><!-- TODO: 그림 제목 --></div>\n%s\n</figure>' % data)
        elif kind == "list":
            html_ = list_html(*data)
        elif kind == "h":
            html_ = '<div class="label">%s</div>' % inline(data)
        else:
            continue
        out.append((pending, html_))
        pending = []
    if pending:
        out.append((pending, ""))
    return lede, out


def estimate_lines(blocks):
    n = 0
    for kind, data in blocks:
        if kind == "p":
            n += 1 + len(data) // 70
        elif kind == "table":
            n += len(data) + 2
        elif kind == "code":
            n += data[1].count("\n") + 3
        elif kind == "svg":
            n += 8
        elif kind == "list":
            n += len(data[1])
        else:
            n += 1
    return n


# ── 카드 ─────────────────────────────────────
def split_questions(text):
    text = re.sub(r"^\*\*(예측|Predict)\*\*\s*[:：]\s*", "", text)
    parts = [p.strip() for p in re.split(r"(?<=\?)\s+|(?<=까),\s*", text) if p.strip()]
    return [p if p.endswith("?") else p + "?" for p in parts] if len(parts) > 1 else [text]


def parse_card(head_line, lines):
    m = CARD.match(head_line)
    title = m.group(3)
    discuss = bool(re.search(r"\[(토론형|discussion)\]", title, re.I))
    pages = page_label(title)
    title = re.sub(r"\[(토론형|discussion)\]", "", strip_pages(title), flags=re.I).strip()
    blocks = parse_blocks(lines)
    pre, ans, mode = [], [], "pre"
    for b in blocks:
        if b[0] == "marker":
            s = b[1]
            if re.search(r"예측|Predict", s):
                pre.append(("write", None))
            elif s.startswith("[[/"):
                mode = "post"
            else:
                mode = "ans"
            continue
        if mode == "ans":
            ans.append(b)
        elif mode == "pre":
            pre.append(b)
        else:
            pre.append(b)  # [[/정답]] 뒤 내용은 드물다: 본문으로
    return {"no": m.group(2), "title": title, "pages": pages, "discuss": discuss, "pre": pre, "ans": ans}


def card_html(c, lb, appendix_no=None):
    body = []
    for kind, data in c["pre"]:
        if kind == "write":
            body.append('<div><div class="label">%s</div><div class="write"><div></div><div></div></div></div>'
                        % lb["predict"])
        elif kind == "p" and re.match(r"^\*\*(예측|Predict)\*\*", data):
            qs = split_questions(data)
            body.append('<ol class="ask">%s</ol>' % "".join("<li><span>%s</span></li>" % inline(q) for q in qs))
        elif kind == "quote" and data[0] == "hint":
            body.append('<p class="hint"><span class="tag">%s</span><span>%s</span></p>' % (lb["hint"], inline(data[1])))
        elif kind == "quote":
            body.append("<p>%s</p>" % inline(data[1]))
        elif kind == "code":
            body.append(code_block(data[0], data[1], lb))
        elif kind == "table":
            body.append(table_bt(data))
        elif kind == "list":
            body.append(list_html(*data))
        elif kind == "svg":
            body.append(data)
        elif kind == "p":
            body.append("<p>%s</p>" % inline(data))
    pill = c["pages"]
    ans = answer_html(c, lb)
    if appendix_no is not None:
        body.append('<p class="answer-ref">%s</p>' % lb["answer_ref"].format(n=appendix_no))
        tail = ""
    else:
        tail = ('\n  <div class="cut"><span class="tag ok">%s</span></div>\n  %s'
                % (lb["criterion"] if c["discuss"] else lb["answer"], ans))
    no = c["no"] + ("<small>%s</small>" % lb["discuss"] if c["discuss"] else "")
    return ('<article class="card">\n  <div class="card-head"><div class="card-no">%s</div>'
            '<div class="card-title">%s</div><span class="pill">%s</span></div>\n'
            '  <div class="card-body">\n    %s\n  </div>%s\n</article>'
            % (no, inline(c["title"]), dash(pill), "\n    ".join(body), tail))


def answer_html(c, lb):
    parts = []
    for i, (kind, data) in enumerate(c["ans"]):
        if kind == "p" and i == 0 and re.fullmatch(r"\*\*(.+)\*\*", data.strip()):
            parts.append('<p class="verdict">%s</p>' % inline(data.strip()[2:-2]))
        elif kind == "p":
            parts.append("<p>%s</p>" % inline(data))
        elif kind == "code":
            if data[0] == "out":
                parts.append('<pre class="out">%s</pre>' % html.escape(data[1]))
            else:
                parts.append(code_block(data[0], data[1], lb))
        elif kind == "table":
            parts.append(table_bt(data))
        elif kind == "list":
            parts.append(list_html(*data))
        elif kind == "quote":
            parts.append("<p>%s</p>" % inline(data[1]))
        elif kind == "svg":
            parts.append(data)
    return '<div class="answer">\n    %s\n  </div>' % "\n    ".join(parts)


# ── 맵 ─────────────────────────────────────
def map_svg(code, lb):
    rows = []
    for line in code.splitlines():
        if not line.strip():
            continue
        prefix = TREE_GLYPH.match(line).group(0)
        depth = len(prefix) // 3 if prefix else 0
        text = line[len(prefix):].strip()
        oos = bool(OOS.search(text))
        text = OOS.sub("", text).strip()
        rows.append((depth, strip_pages(text), page_label(text), oos))
    if not rows:
        return ""
    kids = [r for r in rows[1:] if r[0] >= 1]
    if len(kids) > 8 and rows[0][0] == 0:
        return map_svg_two_col(rows[0], rows[1:], lb)
    h = 30 * len(rows) + 4
    out = ['<svg viewBox="0 0 680 %d" font-family="Pretendard, \'Noto Sans KR\', sans-serif">' % h]
    for i, (d, text, pg, oos) in enumerate(rows):
        x, y = d * 26, 2 + i * 30
        w = 560 - x
        if oos:
            fill, stroke, ink, extra = "#fafbfc", "#8a8f99", "#474c56", ' stroke-dasharray="3 2"'
            text += " (%s)" % lb["oos"]
        elif d == 0:
            fill, stroke, ink, extra = PAL["tint2"], PAL["accent"], PAL["deep"], ""
        else:
            fill, stroke, ink, extra = PAL["tint"], PAL["accent"], PAL["deep"], ""
        if d > 0:
            out.append('<path d="M%d %d V%d H%d" fill="none" stroke="#8a8f99" stroke-width="0.8"/>'
                       % (x - 14, y - 6, y + 12, x))
        weight = ' font-weight="700"' if d == 0 else ""
        out.append('<rect x="%d" y="%d" width="%d" height="24" rx="3" fill="%s" stroke="%s"%s/>'
                   % (x, y, w, fill, stroke, extra))
        out.append('<text x="%d" y="%d" font-size="10.5" fill="%s"%s>%s</text>'
                   % (x + 10, y + 16, ink, weight, html.escape(text)))
        if pg:
            out.append('<text x="572" y="%d" font-size="9" fill="#6b707a" '
                       'font-family="Pretendard, sans-serif">%s</text>' % (y + 16, pg))
    out.append("</svg>")
    return "\n".join(out)


def map_svg_two_col(root, rows, lb):
    """주제가 많으면(8개 초과) 뿌리를 위에 두고 나머지를 두 단으로 흘린다. 표지 한 쪽 안에 들어가게."""
    half = (len(rows) + 1) // 2
    cols = [rows[:half], rows[half:]]
    h = 34 + 26 * half + 4
    out = ['<svg viewBox="0 0 680 %d" font-family="Pretendard, \'Noto Sans KR\', sans-serif">' % h]
    d, text, pg, oos = root
    out.append('<rect x="0" y="2" width="680" height="24" rx="3" fill="%s" stroke="%s"/>' % (PAL["tint2"], PAL["accent"]))
    out.append('<text x="10" y="18" font-size="10.5" font-weight="700" fill="%s">%s</text>' % (PAL["deep"], html.escape(text)))
    if pg:
        out.append('<text x="670" y="18" font-size="9" fill="#4b515c" text-anchor="end">%s</text>' % pg)
    for c, col in enumerate(cols):
        x0 = c * 348
        for i, (d, text, pg, oos) in enumerate(col):
            x, y = x0 + 12 + (d - 1) * 14, 34 + i * 26
            w = 332 - (x - x0)
            if oos:
                fill, stroke, ink, extra = "#fafbfc", "#8a8f99", "#474c56", ' stroke-dasharray="3 2"'
                text += " (%s)" % lb["oos"]
            else:
                fill, stroke, ink, extra = PAL["tint"], PAL["accent"], PAL["deep"], ""
            out.append('<rect x="%d" y="%d" width="%d" height="21" rx="3" fill="%s" stroke="%s"%s/>' % (x, y, w, fill, stroke, extra))
            out.append('<text x="%d" y="%d" font-size="9.5" fill="%s">%s</text>' % (x + 8, y + 14.5, ink, html.escape(text)))
            if pg:
                out.append('<text x="%d" y="%d" font-size="8.5" fill="#6b707a" text-anchor="end">%s</text>' % (x + w - 7, y + 14.5, pg))
    out.append("</svg>")
    return "\n".join(out)


# ── 문서 ─────────────────────────────────────
def defs():
    try:
        s = SPECIMEN.read_text(encoding="utf-8")
        m = re.search(r'<svg width="0" height="0".*?</svg>', s, flags=re.S)
        return m.group(0) if m else ""
    except OSError:
        return ""


def build(md, args):
    head, secs = split_sections(md)
    h1 = next((l[2:].strip() for l in head if l.startswith("# ")), "")
    lang = args.lang if args.lang != "auto" else ("ko" if re.search(r"[가-힣]", h1) else "en")
    lb = L[lang]
    unit_m = re.search(r"(\d+)", h1)
    unit = unit_m.group(1) if unit_m else ""
    topic = h1.split(":", 1)[1].strip() if ":" in h1 else h1
    topic = re.sub(r"\s*\(.*?\)\s*$", "", topic) or topic
    hb = parse_blocks([l for l in head if not l.startswith("# ")])
    source = next((d for k, d in hb if k == "p"), "")
    source = re.sub(r"^(자료|출처|Sources?)\s*[:：]\s*", "", source)
    scope_note = next((d[1] for k, d in hb if k == "quote" and d[0] == "warn"), "")
    scope_m = re.search(r"(?:시험범위|exam scope)\s*[:：]?\s*(p\.\s?\d+\s?[~–-]\s?\d+)", scope_note, re.I)
    oos_m = re.search(r"(p\.\s?\d+\s?[~–-]\s?\d+)\s*(?:는|은)?\s*`?\[(?:시험범위 아님|Out of exam scope)\]", scope_note)

    # 섹션 분류
    topics, summary_secs, review, think, mapcode = [], [], None, None, ""
    for s in secs:
        kind = classify(s["title"])
        if kind == "map":
            code = next((d[1] for k, d in parse_blocks(s["lines"]) if k == "code"), "")
            mapcode = code
        elif kind == "review":
            review = s
        elif kind == "think":
            think = s
        else:
            topics.append((kind, s))

    # 카드
    cards, intro = [], []
    if think:
        cur = None
        for line in think["lines"]:
            if CARD.match(line):
                cur = {"head": line, "lines": []}
                cards.append(cur)
            elif cur is None:
                intro.append(line)
            else:
                cur["lines"].append(line)
        cards = [parse_card(c["head"], c["lines"]) for c in cards]

    # 복습
    qa_rows = []
    if review:
        for k, d in parse_blocks(review["lines"]):
            if k == "table" and len(d) > 1:
                hdr = d[0]
                for r in d[1:]:
                    if len(hdr) >= 3 and re.fullmatch(r"#|No\.?|번호", hdr[0].strip(), re.I):
                        q, a = r[1], r[2] if len(r) > 2 else ""
                    else:
                        q, a = r[0], r[1] if len(r) > 1 else ""
                    qa_rows.append((q, a))
                break

    sec_html, toc = [], []
    num = 0
    for kind, s in topics:
        title = s["title"]
        oos = bool(OOS.search(title))
        pages = page_label(title)
        clean = OOS.sub("", strip_pages(re.sub(r"^\d+\.\s*", "", title))).strip()
        blocks = parse_blocks(s["lines"])
        if oos:  # 범위 밖 섹션 첫 주의 상자는 레일 머리말로 대신한다
            blocks = [b for b in blocks if not (b[0] == "quote" and b[1][0] == "warn"
                                                and re.search(r"시험범위|exam scope", b[1][1], re.I))]
        num += 1
        sid = "s%02d" % num
        lede, items = body_items(blocks, lb)
        short = oos or kind == "summary" or estimate_lines(blocks) < 14
        cls = "sec"  # 이어서 흐른다. 제목만 쪽 끝에 남는 것은 CSS가 막는다
        if kind == "summary":
            src = lb["summary"]
        else:
            src = ("%s주 " % unit if lang == "ko" and unit else "") + pages if pages else ""
        parts = ['<section class="%s" id="%s">' % (cls, sid),
                 '  <header class="head">',
                 '    <div class="badge"><span class="bn">%02d</span><span class="src">%s%s</span></div>'
                 % (num, html.escape(src), '<span class="oos">%s</span>' % lb["oos"] if oos else ""),
                 '    <div class="title"><h2>%s</h2>%s</div>' % (inline(clean), '<p class="lede">%s</p>' % lede if lede else ""),
                 "  </header>"]
        # 범위 밖 표시는 섹션 머리 날개(.src 아래 .oos)에 한 번만 둔다
        for notes, block in items:
            if notes:
                parts.append("  " + rail(notes))
            if block:
                parts.append(block)  # 들여쓰지 않는다: <pre> 안의 공백이 바뀐다
        parts.append("</section>")
        sec_html.append("\n".join(parts))
        toc.append((sid, "%02d" % num, clean, pages + (", " + lb["oos_short"] if oos else "") if kind != "summary" else ""))

    # 생각 카드 섹션
    appendix = args.answers == "appendix"
    if cards:
        num += 1
        parts = ['<section class="sec" id="s%02d">' % num,
                 '  <header class="head">',
                 '    <div class="badge"><span class="bn">%02d</span><span class="src">%s</span></div>'
                 % (num, lb["cards"].format(n=len(cards))),
                 '    <div class="title"><h2>%s</h2><p class="lede">%s</p></div>' % (lb["think"], lb["think_lede"]),
                 "  </header>"]
        for i, c in enumerate(cards, 1):
            parts.append(card_html(c, lb, i if appendix else None))
        parts.append("</section>")
        sec_html.append("\n".join(parts))
        toc.append(("s%02d" % num, "%02d" % num, lb["think"], lb["cards"].format(n=len(cards))))

    if qa_rows:
        rows = []
        for i, (q, a) in enumerate(qa_rows, 1):
            pg = page_label(a)
            a_txt = strip_pages(a).rstrip()
            rows.append('    <tr><td class="no"><span class="box"></span><span class="num">%02d</span></td>'
                        '<td class="q">%s</td><td class="a">%s%s</td></tr>'
                        % (i, inline(q), inline(a_txt), ' <span class="p">%s</span>' % pg if pg else ""))
        sec_html.append("\n".join([
            '<section class="sec" id="sQ">',
            '  <header class="head">',
            '    <div class="badge"><span class="bn">Q</span><span class="src">%s</span></div>' % lb["rows"].format(n=len(qa_rows)),
            '    <div class="title"><h2>%s</h2><p class="lede">%s</p></div>' % (lb["review"], lb["review_lede"]),
            "  </header>",
            '  <table class="qa">',
            '    <thead><tr><th></th><th>%s</th><th class="fold">%s</th></tr></thead>' % (lb["q"], lb["fold"]),
            "    <tbody>", "\n".join(rows), "    </tbody>", "  </table>", "</section>"]))
        toc.append(("sQ", "Q", lb["review"], lb["rows"].format(n=len(qa_rows))))

    if appendix and cards:
        parts = ['<section class="sec page-break appendix" id="sA">',
                 '  <header class="head">',
                 '    <div class="badge"><span class="bn">A</span><span class="src">%s</span></div>' % lb["answer"],
                 '    <div class="title"><h2>%s</h2><p class="lede">%s</p></div>' % (lb["appendix"], lb["appendix_lede"]),
                 "  </header>"]
        for i, c in enumerate(cards, 1):
            parts.append('  <div>\n    <div class="label">A.%d %s</div>\n    %s\n  </div>'
                         % (i, inline(c["title"]), answer_html(c, lb)))
        parts.append("</section>")
        sec_html.append("\n".join(parts))
        toc.append(("sA", "A", lb["appendix"], ""))

    # 표지
    vers = re.findall(r"\(([A-Za-z][\w.+ -]*?\s\d+(?:\.\d+)+)\)", md)
    verify = vers[0] if vers else lb["verify_default"]
    scope_range = dash(scope_m.group(1)) if scope_m else (page_label("(" + re.search(r"p\.\s?\d+\s?[~–-]\s?\d+", source).group(0) + ")") if re.search(r"p\.\s?\d+\s?[~–-]\s?\d+", source) else "")
    oos_range = dash(oos_m.group(1)) if oos_m else ""
    meta = [
        (lb["range"], scope_range, (oos_range + (" 제외" if lang == "ko" else " excluded")) if oos_range else ""),
        (lb["source"], inline(dash(source)), ""),
        (lb["verify"], html.escape(verify), lb["verify_small"]),
    ]
    meta_html = "\n".join('    <div><dt>%s</dt><dd>%s<small>%s</small></dd></div>' % m for m in meta)
    meta_html += '\n    <div class="log"><dt>%s</dt><dd>%s</dd></div>' % (
        lb["log"], "".join("<span>%s</span>" % x for x in lb["log_items"]))
    # 제외 범위가 적혀 있을 때만 "시험범위 아님", 아니면 일반 "주의"
    scope_html = ('  <p class="scope"><span class="tag warn">%s</span>%s</p>\n'
                  % (lb["oos"] if oos_range else lb["warn"], inline(dash(scope_note))) if scope_note else "")
    toc_html = "\n".join(
        '    <a href="#%s"><span class="n">%s</span><span>%s</span><span class="s">%s</span><span class="p">–</span></a>'
        % (sid, n, inline(t), html.escape(dash(s))) for sid, n, t, s in toc)
    cover = "\n".join([
        '<section class="cover">',
        '  <div class="hero">',
        '    <div class="hero-top"><span>%s</span><span>%s</span></div>' % (html.escape(args.course or lb["subject"]),
                                                                          html.escape(args.term or "")),
        '    <div class="hero-num">%s</div>' % (unit.zfill(2) if unit else ""),
        "    <h1>%s</h1>" % inline(topic),
        "    <!-- TODO: <p class=\"sub\">이 단원을 한 줄로</p>, 단원 내용을 그린 .motif SVG (선택) -->",
        "  </div>",
        '  <dl class="meta">', meta_html, "  </dl>",
        scope_html.rstrip("\n"),
        '  <figure class="map"><div class="label">%s</div>' % lb["map"],
        "  " + map_svg(mapcode, lb).replace("\n", "\n  ") if mapcode else "  <!-- TODO: 한 장 요약이 없다 -->",
        "  </figure>",
        '  <nav class="toc"><div class="label">%s</div>' % lb["toc"],
        toc_html,
        "  </nav>",
        "</section>"])
    footer = ("%s주차  %s" % (unit, topic)) if lang == "ko" and unit else (("Week %s  %s" % (unit, topic)) if unit else topic)
    doc = "\n".join([
        "<!doctype html>", '<html lang="%s">' % lang, "<head>", '<meta charset="utf-8">',
        "<title>%s</title>" % html.escape(h1), '<meta name="footer" content="%s">' % html.escape(footer),
        "</head>", "<body style='--unit: \"%s\"; --accent: %s; --accent-deep: %s; --accent-tint: %s'>"
        % (unit, PAL["accent"], PAL["deep"], PAL["tint"]),
        "<!-- scaffold.py가 STUDY.md에서 만든 초안. TODO 주석을 다듬고, render.py --source STUDY.md --fix-toc로 렌더한다 -->",
        defs(), "", cover, "", "\n\n".join(sec_html), "</body>", "</html>", ""])
    return doc, {"lang": lang, "topics": len(topics), "cards": len(cards), "rows": len(qa_rows),
                 "todo": doc.count("<!-- TODO")}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("study")
    ap.add_argument("-o", "--out", help="출력 HTML (기본: STUDY.md 옆에 N주차_공부자료(Topic).html)")
    ap.add_argument("--answers", choices=["inline", "appendix"], default="inline")
    ap.add_argument("--lang", choices=["auto", "ko", "en"], default="auto")
    ap.add_argument("--course", help="표지 왼쪽 위 과목명")
    ap.add_argument("--term", help="표지 오른쪽 위 (학기 · 시험)")
    ap.add_argument("--accent", default="#2b44b8",
                    help="단원 강조색 (기본 남색 #2b44b8). 과목에 맞게 고른다: 청록 #0f6a64, 자주 #7a2b5a, 황토 #8a4a0f 등")
    ap.add_argument("--force", action="store_true", help="이미 있는 HTML을 덮어쓴다")
    a = ap.parse_args()

    src = pathlib.Path(a.study)
    md = src.read_text(encoding="utf-8")
    set_palette(a.accent)
    doc, info = build(md, a)
    if a.out:
        out = pathlib.Path(a.out)
    else:
        h1 = next((l[2:] for l in md.splitlines() if l.startswith("# ")), "")
        unit = (re.search(r"\d+", h1) or [""])[0]
        topic = h1.split(":", 1)[1].strip() if ":" in h1 else src.stem
        topic = re.sub(r"\s*\(.*?\)\s*$", "", topic)
        name = ("%s주차_공부자료(%s).html" % (unit, topic)) if info["lang"] == "ko" else ("Week %s - %s - Study Guide.html" % (unit, topic))
        out = src.with_name(re.sub(r'[\\/:*?"<>|]', "", name))
    if out.exists() and not a.force:
        sys.exit("이미 있다: %s (손본 HTML을 덮어쓰지 않으려고 멈췄다. 덮어쓰려면 --force)" % out)
    out.write_text(doc, encoding="utf-8")
    print("HTML: %s" % out)
    print("섹션 %d, 카드 %d, 복습 %d, TODO %d" % (info["topics"], info["cards"], info["rows"], info["todo"]))


if __name__ == "__main__":
    main()
