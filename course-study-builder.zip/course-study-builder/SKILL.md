---
name: course-study-builder
description: Turn a course's lecture material (required), optional practice material, optional student Q&A or notes, and optional exam info into a verified, exam-oriented summary study sheet (STUDY.md, then PDF) for one week, chapter, or unit. Use when the student asks for 공부 자료, 복습 자료, 요약 정리, 정리본, 시험 대비 자료, 치트시트, a study guide, or a review sheet. Not for setting up a whole course folder or per-course instructions (use course-skill-builder for that).
---

# Course study material builder

A recipe for building a **summary study sheet** for one unit (a week, chapter, or lecture) of any course. It works in Claude Code, in claude.ai with code execution, in any chat assistant (paste this file, then give the inputs), or by hand.

The goal is not a prettier copy of the slides. The goal is a sheet the student can **study from and test themselves with**, in which every claim was either read from the source or checked.

Bundled files (each is read or run only when needed):

| File | Use |
|---|---|
| `scripts/render_study.py` | Renders `STUDY.md` to a styled PDF, handles every custom marker in 6.2, prints lint warnings |
| `assets/style.css` | The design from 6.3 (used by the script) |
| `references/markup.md` | English marker aliases, SVG diagram standards, script options, fallbacks |

Relationship to other skills:
- `study-sheet-design` (optional companion): lays out the finished `STUDY.md` as a designed PDF. This skill decides **what** goes on the sheet; that one decides **how it looks**. Section 6.0 says when to use it.
- `course-skill-builder` (if installed) sets up a course folder and may generate a per-course `SLUG-study` skill. This skill is the generic recipe that such a skill follows for one unit.

---

## 0. Inputs

| Input | Required? | What it is | Typical form |
|---|---|---|---|
| A. Lecture material | **Required** | Slides, lecture notes, textbook chapter, transcript | PDF, PPTX, DOCX, MD, pasted text, images |
| B. Practice material | Optional | Labs, exercises, example code, problem sets, datasets, worked solutions | folder of files, notebook, PDF |
| C. Student Q&A / notes | Optional | Questions the student asked in earlier chats, their own notes, TA answers | chat export, text |
| D. Assignment / exam info | Optional | Assignment guide, grading rules, exam scope, past exam style | text, PDF |

Ask for A only if it is missing. For B, C, D: use them if given, **say plainly in the final report which were used and which did not exist**, and never block on them.

Parameters to confirm once (use these defaults if the student does not care):

| Parameter | Default |
|---|---|
| Output language | The student's language (Korean for a Korean student), even if they type in English. Keep code, commands, formulas, and error messages as they are |
| Unit name and number | From the file name or the first slide, e.g. `6주차` / `Chapter 6` |
| Exam scope | Everything in A. If the student says "from page X on is not in the exam", mark that part (see 3.3) |
| Answer placement | `inline`: the answer sits in the same card. `appendix`: answers are collected at the end of the PDF so the printed sheet can be used for real self-testing |
| Output | `STUDY.md` plus a rendered PDF named `N주차_공부자료(Topic).pdf` (or `Week N - Topic - Study Guide.pdf`) |
| Unfinished assignment | Explain concepts, but do not write the solution the student is supposed to write |

---

## 1. Workflow

1. **Intake.** List the inputs received, the unit, the scope, and anything unreadable. Ask at most one short question, and only if the answer changes the work (for example, the exam scope is unknown and the unit is long).
2. **Read everything.** Read every page of A, not only the pages with examples. Read all of B. See section 5 for awkward formats.
3. **Map.** Write a private outline: slide/page range → topic. Note which pages are diagrams only, which examples exist in B, and where the slide and the practice material disagree.
4. **Mine C.** The student's own questions are the most valuable material, because they show exactly where this student got stuck. Keep the question and a corrected, shortened answer, and cite it ("10/16 질문").
5. **Verify.** For anything checkable, check it (section 4). Collect only observed results.
6. **Write `STUDY.md` incrementally**, section by section with file tools, to avoid truncated output. Decide the card and question counts first (rule in 2.0), then write every card and question you committed to in full. Never skip or cut one you planned. If you end up with fewer, say so and why in the report.
7. **Lint, then render.** Always lint `STUDY.md` first (`render_study.py STUDY.md --lint-only`, 6.4) and fix or explain every warning. Then choose the render path (6.0): the design path hands `STUDY.md` to `study-sheet-design`; the Markdown path renders with the script (6.4). Either way, **look at the pages** (6.5).
8. **Report** briefly: file paths, page count, which render path was used (and why, if the design path was skipped), sources used, what was newly verified or corrected, what was left out and why.

Read limits. If a file is too large, unreadable, or unsupported, report which pages or sections were read and which were not. Do not imply full coverage. Ask for a readable version only when the missing material would change the study sheet.

Keep the reply to the student short, with the result first.

---

## 2. Structure of the study sheet

Title: `# N주차 공부 자료 : <Topic>`, then **one line naming the sources** (file names and page ranges). If part of the unit is out of exam scope, put the scope note directly under the title (see 3.3).

| # | Section | Notes |
|---|---|---|
| 0 | 한 장 요약 | One code block: the whole unit as a tree or flow, with `(p.N)` on every line. Lines must be short enough not to wrap |
| 1..k | One `##` per topic, in source order, with `(p.A~B)` in the heading | See 2.1 |
| k+1 | 정리 / 공식·명령어·핵심 정의 모음 | Cheat-sheet: formulas, commands, definitions, comparison tables |
| k+2 | 실습 자료 현황 | **Only if B exists.** Table: item, source page, status or note |
| k+3 | 복습 질문 | 2-column table `질문 / 정답`; the answer sits next to the question |
| k+4 | 생각해 보기 (예측 → 실행/풀이 → 설명) | The main self-test section (2.2) |

### 2.0 Counts (one rule, used everywhere)

Default: **8~9 생각해 보기 cards** and **about 20 복습 질문 rows**. Scale both to the unit's length and learning goals: fewer for a short or thin unit, never padded with repetitive or weak items to hit the number. Whatever count you choose, every item is written in full (workflow step 6), and a count below the default is mentioned in the report.

### 2.1 A topic section

In this order, skipping what does not apply:

1. **Core concept, readable first**: The main idea in one or two sentences. Put the most important one first: the design path uses only the first sentence as the section's lead line. Avoid long blocks of uninterrupted text; break complex concepts down with tables, bullet lists, diagrams, and short marked notes.
2. First use of a term: native term plus the original in parentheses, for example 파일 디스크립터(file descriptor, fd).
3. **Diagram** for architectures, memory maps, flows, or execution models: an inline SVG (raw HTML block, standards in `references/markup.md`) or a clean ASCII diagram in a code block.
4. The definition, signature, or formula in a code/math block, with return values or conditions.
5. A table for anything that is a list of options, cases, or an A-versus-B comparison.
6. The source example (from A or B), shortened to the lines that matter, with what each line does.
7. The real output, if it was obtained (section 4), in an `out` block.
8. `> **주의**:` boxes for mistakes in the slides, common traps, and surprises.
9. `> **참고**:` boxes for questions this student actually asked (C).

Do not paste a full solution to an assignment that is still open. For finished assignments, describe the flow and the key lines instead of dumping the whole file.

### 2.2 생각해 보기 (self-test problems)

The point is to make the student **predict and explain**, not just recall. Recall questions alone are not enough.

Open the section with the routine:

1. Read the problem and **write a prediction before running or solving**.
2. If stuck, read only the hint.
3. Run or solve it yourself.
4. Compare with the answer and explain where the prediction went wrong.

Each problem is one card. Standard card (a problem with a checkable result):

```
### 생각 N. <question title> (p.A~B)

<a short snippet, scenario, or calculation the student can actually run or do>

**예측**: <2~3 concrete questions: what is printed, what value, why>

[[예측]]

> **힌트**: <one line pointing at the page or concept, never the answer>

[[정답]]
**<The observed or computed result in bold, one sentence.>**

<Output or working. Then why. Then what it teaches or where it shows up in practice.>
[[/정답]]
```

Discussion card (the "Design it" type, where there is no single correct result). Same markers, different answer panel:

```
### 생각 N. <question title> (p.A~B) [토론형]

<a scenario with real constraints>

**예측**: <which options exist, which one you would pick, what decides it>

[[예측]]

> **힌트**: <one line pointing at the trade-off, never a verdict>

[[정답]]
**<The criterion that decides between the options, in one sentence. Not a single verdict.>**

| 선택지 | 맞는 경우 | 비용 |
|---|---|---|
| ... | ... | ... |

<What the material says about it (p.N), and what it leaves open.>
[[/정답]]
```

- Mix the types, and stay inside this unit's material:
  - **Predict before running**: a small change to a source example
  - **Discover by experiment**: something the material implies but never shows
  - **Edge cases**: errors, empty input, limits, wrong units, boundary values
  - **Find the bug**: a plausible wrong version of a source example
  - **Design it**: one open-ended question, using the discussion card
- Link problems to each other and to the assignment when it helps.
- For non-programming subjects the same card works: a calculation with changed numbers, a case to classify, an argument to critique, a proof step to justify, a graph to read. "Run it" becomes "work it out on paper".

### 2.3 복습 질문

About 20 rows (see 2.0), table `질문 | 정답`, numbered. One fact or one explanation per row, answer in one to three sentences with the page in parentheses. Say in the intro that the questions are for self-study, not official exam questions.

---

## 3. Writing rules

### 3.1 Style

- Short sentences. Result first, reasoning after.
- Tables for comparisons and option lists. ASCII diagrams in code fences for layouts, flows, and memory or data structures.
- `**bold**` for the **one key phrase** per paragraph, never whole sentences, never whole paragraphs. No underline or highlight (see 6.3).
- No emojis. No filler such as "let's dive in".
- Keep code, commands, formulas, and error messages exactly as they are, in backticks or code blocks.
- Mark source mistakes explicitly (typo in a slide, wrong formula, code that does not compile) and say what the sheet changed.
- Use only the markup in 6.2: no nested lists, no image files, no links inside the body, no italics, and raw HTML only for SVG diagrams. Write around these.

### 3.2 Honesty rules

- **Never invent facts** to fill a gap. If the material is silent, write "자료에 없음" and, if useful, mark any addition as `(보충: 강의자료 밖 내용)`.
- **Never present self-made questions as official exam questions.**
- **Label anything unverified** as `(미검증)`. If an earlier chat answer turns out to be wrong when checked, write the observed behavior and tell the student about the correction.
- Diagram-only or image-only pages: describe them from the surrounding pages, and say that the page was image-only.
- If something depends on the environment (compiler, version, locale, calculator mode), say so.

### 3.3 Exam scope

If the student states a scope (for example "up to slide 41 only"):

- Put a `> **주의**:` box right under the title that states the range and which part is excluded.
- Keep the excluded part in the sheet, because it is still useful, but title it `[시험범위 아님]` and add a one-line box at its top.
- Do not write self-test problems for excluded parts, except where a problem is really about an in-scope idea.
- Record the scope where the next session will see it (a note file or the project's instructions).

---

## 4. Verification

The sheet's value comes from claims that were checked.

| Material type | How to verify |
|---|---|
| **Executable code and scripts** | Build and run in a throwaway directory. Quote real output; test at least one edge case or error condition |
| **Mathematical, statistical, quantitative claims** | Programmatically or step by step recompute worked examples, equations, and data calculations. Check units, rounding, and boundary values |
| **Commands, configs, system calls** | Test against a local sandbox, dry-run flags (`--dry-run`, `--plan`, mock mode), or help tools. **Never modify live system state or run paid external operations** |
| **Definitions, theorems, conceptual models** | Cross-check against lecture text; explicitly flag any ambiguities or discrepancies found in the source slides |
| **Unexecutable / non-verifiable** | Reason logically through the steps, then mark the result `(미검증, 직접 실행해 보지 못함)` |

Rules:
- Use only output you actually saw. Do not "tidy" outputs.
- Use temporary files only; never touch the student's own files or assignment folders. Delete temporary files afterwards.
- If the behavior can differ by tool version or platform, name the version or platform you used.
- If a verified result contradicts the lecture, report both and explain.

---

## 5. Reading awkward inputs

| Input | How |
|---|---|
| Text PDF | Extract all pages as text with any tool (for example `pdftotext -layout`, Python `pypdf`, or copy-paste). Keep page numbers |
| Image-only slides or scans | Look at the page images directly; OCR if available; otherwise ask the student for the text of those pages |
| PPTX/DOCX | Export to PDF or plain text first, keep slide numbers |
| Notebooks (`.ipynb`) | Read cell by cell; run it if the environment allows |
| Folder of code or files | List it, read each file, run the test or build step if there is one |
| Chat exports | Pick the questions that belong to this unit; keep the student's wording of the question |

If the tool is missing and cannot be installed, ask the student to paste the text of the needed pages. Do not guess page contents.

---

## 6. Rendering

### 6.0 Choose the render path

Two paths produce the PDF. `STUDY.md` is the source of truth in both, and everything in sections 2 to 4 still applies.

| Path | Use when | How |
|---|---|---|
| **Design path** | The `study-sheet-design` skill is installed **and** its browser check passes: `python "<study-sheet-design folder>/scripts/render.py" --check` prints a browser path | Follow that skill. It turns `STUDY.md` into hand-composed HTML (left meta rail, numbered figures and equations, SVG diagrams, self-test cards) and prints it with Chromium |
| **Markdown path** | The design skill is missing, the browser check fails, or the student wants a quick plain version | `render_study.py` with `assets/style.css` (6.4). Same design principles in a simpler form |

Rules for choosing:
- Run the lint (`--lint-only`, 6.4) before either path. The design path has no Markdown lint of its own.
- If the design path was expected but the browser check fails, use the Markdown path and say so in the report in one line. Do not stop to ask.
- Answers in the appendix (`--answers appendix`) and English output work on both paths. The design skill's SKILL.md describes how.
- The design path's own checklist cross-checks the HTML against `STUDY.md` (card and question counts, page numbers). Treat a mismatch the same way as a lint warning.

### 6.1 Output naming and placement

`STUDY.md` (fixed name) and the PDF `N주차_공부자료(Topic).pdf` next to it, in the unit's folder. The PDF title banner shows the unit number, and the footer shows `N주차 · Topic  page / total` on every page.

### 6.2 Markdown subset and markers

Plain Markdown: headings `#`~`####`; fenced code blocks; `|` tables; `>` quotes; flat `-` and `1.` lists; `` `code` ``; `**bold**`. Raw HTML is allowed only for `<svg>` diagrams. The script handles these extra markers, each with a plain-text fallback so the raw file still reads well:

| Marker | Meaning | Fallback if the renderer does not know it |
|---|---|---|
| `> **주의**:` | warning: lead word in red on a light red tint | looks like a normal quote |
| `> **핵심**:` / `> **참고**:` | key point / note: lead word in blue, no box | same |
| `> **힌트**:` | hint: lead word in amber on a light amber tint | same |
| ```` ```out ```` | observed output on a light green surface | plain code block |
| `[[예측]]` | empty write-in box for the prediction | a line `[[예측]]`; replace with a blank bordered area |
| `[[정답]]` ... `[[/정답]]` | Answer panel inside the problem card | a visible green box in PDF. In interactive HTML, `<details><summary>정답</summary> ... </details>` also works |

English aliases (`Warning`, `Key`, `Note`, `Hint`, `[[Predict]]`, `[[Answer]]`, card heading `### Think N.`) are listed in `references/markup.md`.

### 6.3 Design

Implemented in `assets/style.css`; change it there, not in the Markdown. The color values and the "avoid" list are shared with `study-sheet-design` (`assets/study.css` there). If you change one of them, change the other to match.

- A4, margins about 14 mm, body 10.5 pt, a Korean-capable font, monospace for code with ligatures off so `->`, `!=`, `==` print as typed.
- **Color by meaning only**: blue for concepts and bold, red for warnings, green for observed output and answers, amber for hints. Color goes on text, rules, and light surfaces only.
- Hierarchy comes from print conventions: sections open with a thin rule and a short heavy blue segment, not a filled bar. Tables use three horizontal rules (booktabs) with no vertical lines, no filled header, and no zebra stripes. Callout labels are the colored lead word itself.
- **Avoid template-UI patterns that make a page look AI-made**: left-stripe callout boxes, pill or badge labels, small eyebrow text above headings, gradient washes, drop shadows, emoji.
- Problem cards: thin frame, blue header band, a ruled write-in area, the hint on a light amber tint, and the answer on a light green surface inside the same card.
- **Bold text is just bold plus the accent color: no underline, no highlighter band.** A dark underline under bold text made a previous version hard to read.
- Clickable table of contents built from the `##` headings, shown on page 1, with page numbers.
- Keep code lines short enough not to wrap; keep the one-page summary tree within the page width.

### 6.4 Rendering the PDF

```
python3 <skill folder>/scripts/render_study.py STUDY.md -o "N주차_공부자료(Topic).pdf" --footer "N주차 · Topic"
```

Lint only (no files written; use this before either render path):

```
python3 <skill folder>/scripts/render_study.py STUDY.md --lint-only
```

Add `--answers appendix` when the student wants the printed sheet to hide the answers. The script needs Python with `markdown` and `weasyprint` (`pip install markdown weasyprint`). It prints lint warnings (leftover `**` or `[[`, card or question counts far from 2.0, cards missing a prediction box, hint, or answer, topic headings without a page reference). Warnings are for you to fix or explain, not to hide.

If `weasyprint` cannot be installed: run the script with `--html-only` and print the HTML to PDF from a browser, or use pandoc (`pandoc STUDY.md -o out.pdf --pdf-engine=xelatex -V CJKmainfont="Noto Sans CJK KR"`, plain look, markers not styled). Details in `references/markup.md`.

### 6.5 Look at the result

Convert pages to images and view them:

```
pdftoppm -r 60 -png out.pdf /tmp/study_preview
```

View at least the first page, a dense page, a self-test page, and the last page. Check for visible `**`, wrapped table headers, code turned into symbols, boxes cut across pages, and text running off the page. Fix the Markdown or CSS and rebuild. Delete the preview images afterwards.

---

## 7. Final checklist

- [ ] Every page or section of A is covered, in source order, with `(p.N)` references
- [ ] Scope note present if the student gave a scope; excluded parts titled `[시험범위 아님]`
- [ ] Every example result or number was observed or recomputed, or is marked `(미검증)`
- [ ] Source mistakes are flagged with `> **주의**:`
- [ ] The student's own questions (C) appear where they belong, with the date or source
- [ ] Card and question counts follow 2.0. Each card has a prediction box, a one-line hint, and an answer (inline or in the appendix)
- [ ] 복습 질문 table has answers next to the questions
- [ ] Open assignments are explained but not solved
- [ ] Bold is sparse and has no underline or highlighter
- [ ] `--lint-only` ran on `STUDY.md` and every warning is fixed or explained
- [ ] Render path chosen per 6.0. Markdown path: footer shows unit and page numbers on every page. Design path: its render checklist passed (cover page has no footer by design), and the cross-check against `STUDY.md` shows no mismatch
- [ ] PDF named correctly; pages were looked at
- [ ] Temporary files removed; the student's own files untouched
- [ ] Report: paths, page count, render path used, sources used (and which did not exist), corrections, omissions

---

## 8. Quick start prompt (copy and fill in)

```
Use the course-study-builder recipe.

Course: <name>            Unit: <week / chapter number and topic>
Lecture material (required): <files or pasted text>
Practice material (optional): <files, or "none">
My earlier questions / notes (optional): <paste, or "none">
Assignment or exam info (optional): <guide, exam scope such as "pages 1-41 only", or "none">
Language: <Korean / English>
Answers: <inline / appendix>
Output: STUDY.md and a PDF named "<N>주차_공부자료(<Topic>).pdf"
Do not solve my open assignment. Mark anything outside the exam scope as [시험범위 아님].
```
