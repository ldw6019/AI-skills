# Markup, SVG, and renderer reference

Read this file when you need an English marker alias, SVG standards, script options, or a fallback renderer. It is a single flat reference with no links to other reference files.

## English marker aliases

Use these when the output language is English. `render_study.py` accepts both columns; do not mix languages inside one sheet.

| Korean | English | Result |
|---|---|---|
| `> **주의**:` | `> **Warning**:` or `> **Caution**:` | warning: red lead word on a light red tint |
| `> **핵심**:` | `> **Key**:` | key point: blue lead word, no box |
| `> **참고**:` | `> **Note**:` | note: blue lead word, no box |
| `> **힌트**:` | `> **Hint**:` | hint: amber lead word on a light amber tint |
| `[[예측]]` | `[[Predict]]` | write-in prediction box |
| `[[정답]]` ... `[[/정답]]` | `[[Answer]]` ... `[[/Answer]]` | answer panel |
| `### 생각 N. title (p.A~B)` | `### Think N. title (p.A~B)` | problem card heading (starts a card) |
| `[시험범위 아님]` | `[Out of exam scope]` | plain heading text, no special handling |
| `## 한 장 요약` | `## One-page summary` | first section |
| `## 복습 질문` | `## Review questions` | review table section |
| `## 생각해 보기` | `## Think it through` | self-test section |

A card ends at the next `##` or `###` heading. Keep exactly one `[[예측]]` and one answer panel per card.

## SVG diagram standards

- Write the SVG as a raw HTML block, starting at the beginning of a line, with a blank line before and after.
- Use `viewBox="0 0 W H"` and `width="100%"`, inline styles only, no external fonts or images.
- Make W about 700. The printed text column is about 690 px wide, so a 700-wide viewBox prints text close to its nominal size; a much narrower viewBox gets stretched and its text prints oversized (seen in testing with a 360-wide viewBox).
- Colors (same palette as `study-sheet-design/reference/svg.md`): strokes `#17191e` (ink) or `#2b44b8` (concept), fills `#f4f5f7` or `#eef1fb`, text `#17191e`, secondary text `#4b515c`. Red `#c2461d` only for warnings or forbidden areas, green `#1d7a57` only for verified results.
- On the design path these SVGs are redrawn at the design skill's 540 width with its arrow markers. Keep the STUDY.md SVG simple: it is the content reference, not the final drawing.
- Keep it small (a few dozen elements). Text inside the SVG should be at least 10 px at the rendered size.
- If the PDF engine renders it badly, replace it with an ASCII diagram in a code block.

## Script options

`python3 scripts/render_study.py STUDY.md [options]`

| Option | Meaning |
|---|---|
| `-o FILE` | output PDF (default: same name as the input, `.pdf`) |
| `--footer TEXT` | footer text before `page / total` (default: the h1 text) |
| `--answers inline\|appendix` | answer in the card (default) or collected in an appendix at the end |
| `--lang auto\|ko\|en` | language of generated labels such as the table of contents title (default: auto, from the h1) |
| `--css FILE` | extra CSS appended after `assets/style.css` |
| `--html-only` | write the HTML and stop (for browser printing) |
| `--keep-html` | also keep the HTML next to the PDF |
| `--strict` | exit with status 1 if there are lint warnings |
| `--lint-only` | print lint warnings and stop; writes no file. Run it before either render path (SKILL.md 6.0) |

Requirements: Python 3, `markdown`, `weasyprint`. Exit status 2 means the PDF engine is missing; the HTML is still written.

## Fallbacks when weasyprint is unavailable

- Browser: run with `--html-only`, open the HTML, print to PDF with A4 paper and background graphics on.
- Pandoc: `pandoc STUDY.md -o out.pdf --pdf-engine=xelatex -V CJKmainfont="Noto Sans CJK KR"`. Plain look. The markers are not styled, so `[[예측]]` and `[[정답]]` show as text lines; that is acceptable but tell the student.

## Fonts

Preferred: Pretendard or Noto Sans KR for text, D2Coding for code. The CSS falls back to Noto Sans CJK KR and DejaVu Sans Mono. If no Korean-capable font is installed, Hangul prints as empty boxes; say so and ask for a machine with a font, or use the browser route.
