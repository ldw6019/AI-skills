#!/usr/bin/env python3
"""Render a study sheet (STUDY.md) to a styled PDF.

Handles the custom markers described in SKILL.md 6.2: callout quotes, `out`
code blocks, [[예측]] boxes, [[정답]] panels, problem cards, a table of contents,
and a footer with page numbers. Prints lint warnings for the final checklist.

Usage:
  python3 render_study.py STUDY.md -o out.pdf --footer "6주차 · Topic"
  python3 render_study.py STUDY.md --answers appendix
  python3 render_study.py STUDY.md --html-only
  python3 render_study.py STUDY.md --lint-only     # lint before the design path

Requires: Python 3, `markdown`, and `weasyprint` (not needed with --html-only).
"""
import argparse
import html
import re
import sys
from pathlib import Path

try:
    import markdown
except ImportError:
    sys.exit("The 'markdown' package is required: pip install markdown")

HERE = Path(__file__).resolve().parent
DEFAULT_CSS = HERE.parent / "assets" / "style.css"

CALLOUTS = {
    "주의": "warn", "Warning": "warn", "Caution": "warn",
    "핵심": "key", "Key": "key",
    "참고": "note", "Note": "note",
    "힌트": "hint", "Hint": "hint",
}
LABELS = {
    "ko": {"predict": "예측을 여기에 적기", "answer_ref": "정답은 맨 뒤 부록 '{t}' 참고",
           "toc": "목차", "appendix": "부록: 생각해 보기 정답"},
    "en": {"predict": "Write your prediction here", "answer_ref": "Answer is in the appendix at the end: '{t}'",
           "toc": "Contents", "appendix": "Appendix: Answers to the self-test"},
}

FENCE = re.compile(r"^\s*(```|~~~)")
HEADING = re.compile(r"^#{2,3}\s")
CARD = re.compile(r"^###\s+(생각|Think)\s*\d+")
PREDICT = re.compile(r"^\s*\[\[(예측|Predict)\]\]\s*$")
ANS_OPEN = re.compile(r"^\s*\[\[(정답|Answer)\]\]\s*$")
ANS_CLOSE = re.compile(r"^\s*\[\[/(정답|Answer)\]\]\s*$")


def preprocess(text, answers, labels):
    """Turn markers into HTML blocks that python-markdown (md_in_html) understands."""
    out, buf, collected = [], [], []
    in_fence = in_card = capturing = False
    title = ""

    def emit(line):
        (buf if capturing else out).append(line)

    for line in text.splitlines():
        if FENCE.match(line):
            in_fence = not in_fence
            emit(line)
            continue
        if in_fence:
            emit(line)
            continue
        if HEADING.match(line) and not capturing:
            if in_card:
                out += ["", "</div>", ""]
                in_card = False
            if CARD.match(line):
                title = re.sub(r"^###\s+", "", line).strip()
                out += ['<div class="card" markdown="1">', ""]
                in_card = True
            out.append(line)
            continue
        if PREDICT.match(line):
            emit("")
            emit('<div class="predict">%s</div>' % labels["predict"])
            emit("")
            continue
        if ANS_OPEN.match(line):
            if answers == "appendix":
                capturing, buf = True, []
            else:
                out += ["", '<div class="answer" markdown="1">', ""]
            continue
        if ANS_CLOSE.match(line):
            if answers == "appendix" and capturing:
                collected.append((title, buf))
                capturing = False
                out += ["", '<div class="answer-ref">%s</div>' % labels["answer_ref"].format(t=html.escape(title)), ""]
            else:
                out += ["", "</div>", ""]
            continue
        emit(line)

    if in_card:
        out += ["", "</div>", ""]
    if answers == "appendix" and collected:
        out += ["", '<div class="pagebreak"></div>', "", "## " + labels["appendix"], ""]
        for t, body in collected:
            out += ["### " + t, "", '<div class="answer" markdown="1">', ""] + body + ["", "</div>", ""]
    return "\n".join(out)


def to_html(md_text):
    md = markdown.Markdown(extensions=["tables", "fenced_code", "md_in_html", "sane_lists"])
    return md.convert(md_text)


def postprocess(body, labels):
    def callout(m):
        cls = CALLOUTS.get(m.group(2))
        if not cls:
            return m.group(0)
        return '<blockquote class="%s">%s%s%s' % (cls, m.group(1), m.group(2), m.group(3))

    body = re.sub(r"<blockquote>(\s*<p><strong>)([^<]+)(</strong>)", callout, body)
    body = body.replace('<pre><code class="language-out">', '<pre class="out"><code>')

    heads = []

    def add_id(m):
        n = len(heads) + 1
        heads.append((n, m.group(1)))
        return '<h2 id="sec-%d">%s</h2>' % (n, m.group(1))

    body = re.sub(r"<h2>(.*?)</h2>", add_id, body, flags=re.S)
    if heads:
        items = "".join('<li><a href="#sec-%d">%s</a></li>' % (n, t) for n, t in heads)
        toc = '<nav class="toc"><h2 class="toc-title">%s</h2><ol>%s</ol></nav>' % (labels["toc"], items)
        body = body.replace('<h2 id="sec-1">', toc + '<h2 id="sec-1">', 1)
    return body


def lint(body, answers):
    warns = []
    no_pre = re.sub(r"<pre.*?</pre>", "", body, flags=re.S)
    plain = re.sub(r"<[^>]+>", "", no_pre)
    if "**" in plain:
        warns.append("leftover '**' outside code: some bold did not render (check spacing around the asterisks)")
    if "[[" in plain:
        warns.append("leftover '[[' outside code: an unmatched or misspelled marker")

    cards = body.count('<div class="card"')
    predicts = body.count('class="predict"')
    answer_panels = body.count('class="answer"')
    hints = body.count('<blockquote class="hint"')
    if cards == 0:
        warns.append("no self-test cards found (heading must start with '### 생각 N.' or '### Think N.')")
    elif cards < 5:
        warns.append("only %d card(s); SKILL.md 2.0 default is 8~9. Fine for a short unit, but say so in the report" % cards)
    if cards and predicts != cards:
        warns.append("%d cards but %d prediction boxes" % (cards, predicts))
    if cards and answer_panels != cards:
        warns.append("%d cards but %d answer panels" % (cards, answer_panels))
    if cards and hints < cards:
        warns.append("%d cards but only %d hint boxes" % (cards, hints))

    for m in re.finditer(r'<h2 id="sec-\d+">(.*?)</h2>(.*?)(?=<h2 id="sec-|\Z)', body, flags=re.S):
        name = re.sub(r"<[^>]+>", "", m.group(1))
        if re.search(r"복습|Review", name):
            rows = m.group(2).count("<tr>") - 1
            if rows < 15:
                warns.append("review section has %d rows; SKILL.md 2.0 default is about 20" % rows)
            elif rows > 30:
                warns.append("review section has %d rows; consider trimming (2.0)" % rows)

    structural = re.compile(r"요약|정리|모음|복습|생각|실습|부록|summary|cheat|review|think|practice|appendix|contents|목차", re.I)
    missing = [re.sub(r"<[^>]+>", "", t) for t in re.findall(r'<h2 id="sec-\d+">(.*?)</h2>', body, flags=re.S)]
    missing = [t for t in missing if not structural.search(t) and "(p." not in t and "[시험범위 아님]" not in t]
    if missing:
        warns.append("topic headings without a page reference '(p.N)': " + "; ".join(missing))
    return warns


def make_page_css(footer):
    safe = footer.replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")
    # page margin boxes do not inherit the body font, so name it here too
    return ('@page { @bottom-center { content: "%s   " counter(page) " / " counter(pages); '
            'font-family: "Pretendard", "Noto Sans KR", "Noto Sans CJK KR", "NanumBarunGothic", sans-serif; '
            'font-size: 8.5pt; color: #57606a; } }' % safe)


def main():
    ap = argparse.ArgumentParser(description="Render STUDY.md to a styled PDF")
    ap.add_argument("input")
    ap.add_argument("-o", "--output")
    ap.add_argument("--footer")
    ap.add_argument("--answers", choices=["inline", "appendix"], default="inline")
    ap.add_argument("--lang", choices=["auto", "ko", "en"], default="auto")
    ap.add_argument("--css", help="extra CSS appended after the default stylesheet")
    ap.add_argument("--html-only", action="store_true")
    ap.add_argument("--keep-html", action="store_true")
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--lint-only", action="store_true",
                    help="print lint warnings and exit without writing any file")
    args = ap.parse_args()

    src = Path(args.input)
    text = src.read_text(encoding="utf-8")
    h1 = re.search(r"^#\s+(.+)$", text, flags=re.M)
    h1_text = h1.group(1).strip() if h1 else src.stem
    lang = args.lang
    if lang == "auto":
        lang = "ko" if re.search(r"[\uac00-\ud7a3]", h1_text) else "en"
    labels = LABELS[lang]

    body = postprocess(to_html(preprocess(text, args.answers, labels)), labels)
    warns = lint(body, args.answers)

    if args.lint_only:
        for w in warns:
            print("LINT:", w, file=sys.stderr)
        print("lint: %d warning(s)" % len(warns))
        sys.exit(1 if (warns and args.strict) else 0)

    css = DEFAULT_CSS.read_text(encoding="utf-8")
    if args.css:
        css += "\n" + Path(args.css).read_text(encoding="utf-8")
    css += "\n" + make_page_css(args.footer or h1_text)
    doc = ('<!doctype html><html lang="%s"><head><meta charset="utf-8"><title>%s</title>'
           "<style>%s</style></head><body>%s</body></html>") % (lang, html.escape(h1_text), css, body)

    out_pdf = Path(args.output) if args.output else src.with_suffix(".pdf")
    html_path = out_pdf.with_suffix(".html")

    for w in warns:
        print("LINT:", w, file=sys.stderr)

    if args.html_only:
        html_path.write_text(doc, encoding="utf-8")
        print("wrote", html_path)
    else:
        try:
            from weasyprint import HTML
        except Exception as e:  # ImportError, or missing system libraries
            html_path.write_text(doc, encoding="utf-8")
            print("PDF engine unavailable (%s). Wrote %s; print it to PDF from a browser, "
                  "or install weasyprint." % (e, html_path), file=sys.stderr)
            sys.exit(2)
        HTML(string=doc, base_url=str(src.parent.resolve())).write_pdf(str(out_pdf))
        if args.keep_html:
            html_path.write_text(doc, encoding="utf-8")
        print("wrote", out_pdf)

    if warns and args.strict:
        sys.exit(1)


if __name__ == "__main__":
    main()
