# 실습 7-3: 사용자 정의 예외
class ScoreError(Exception):
    pass

def check(score):
    if not 0 <= score <= 100:
        raise ScoreError(f"점수 범위 밖: {score}")
    return score

for s in [90, 105, -1]:
    try:
        print("통과:", check(s))
    except ScoreError as e:
        print("오류:", e)
