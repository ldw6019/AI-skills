# 실습 7-1: 나눗셈 계산기
def divide(a, b):
    try:
        result = a / b
    except ZeroDivisionError:
        print("0으로 나눌 수 없습니다")
        return None
    else:
        print("계산 성공")
        return result
    finally:
        print("divide 끝")

print(divide(10, 2))
print(divide(1, 0))
