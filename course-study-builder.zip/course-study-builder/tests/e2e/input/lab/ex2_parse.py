# 실습 7-2: 정수 목록 읽기
def parse_all(items):
    nums = []
    for s in items:
        try:
            nums.append(int(s))
        except ValueError as e:
            print("건너뜀:", e)
    return nums

print(parse_all(["3", "x", "10", "4.5"]))
