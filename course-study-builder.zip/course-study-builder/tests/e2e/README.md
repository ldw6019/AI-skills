# End-to-end test: 7주차 예외 처리 (fictional course)

A complete input set for checking that the two skills alone turn class material into the finished study sheet. The lecture, labs and questions are made up for testing; they are not a real course.

## Input (`input/`)

| File | Role (SKILL.md section 0) |
|---|---|
| `07-예외처리.pdf` | A. Lecture, 16 slides |
| `lab/ex1_divide.py`, `lab/ex2_parse.py`, `lab/ex3_score.py` | B. Practice code |
| `과제3_안내.md` | D. Open assignment (due 11/3) |
| `이전_질문.txt` | C. Earlier student questions with the answers given then |

Request to give with it: "7주차 공부자료 만들어줘. 시험은 14쪽까지."

## Traps the run must catch

- Slide 13 says finally does not run when try contains a return. That is wrong: running it shows finally runs. The sheet must mark it with `> **주의**:` and show the observed output.
- The 10/20 answer ("catching Exception for everything is safe") is wrong. The sheet must correct it, citing slide 13.
- The 10/22 answer is right and is kept.
- 과제 3 is open: concepts only, no solution.
- Exam scope is p.1–14: p.15–16 become `[시험범위 아님]`, with no self-test cards.
- `pdftotext -layout` scrambles the code on slides 4 to 6 (Korean strings split from their lines). Read with PyMuPDF.

## Expected result

`expected/STUDY.md` is one correct output (Python 3.13.17). Another run may word things differently, but it should pass the same checks:

```
python3 ../../scripts/render_study.py STUDY.md --lint-only                        # 0 warnings
python3 <design>/scripts/scaffold.py STUDY.md --course "프로그래밍 기초 (파이썬)" --term "2026-2" --accent "#2b44b8"
# polish every <!-- TODO --> (cover line, two diagrams as SVG)
python3 <design>/scripts/render.py "7주차_공부자료(예외 처리).html" --source STUDY.md --fix-toc
```

The render must print no `대조:` warning other than "차이 없음", "차례: 쪽 번호가 실제와 맞다", "대비: 모든 글자가 WCAG AA 기준을 넘는다", and no `쪽 끝 제목:` or `TODO:` line. The cover must show 범위 p.1–14 with p.15–16 excluded. The reference run gave 14 pages.
