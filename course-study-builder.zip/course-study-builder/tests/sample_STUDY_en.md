# Week 3 Study Guide : Python Slicing (renderer test fixture)

Sources: fictional lecture notes `slicing.pdf` p.1~4 (not a real course, for renderer checks only)

## One-page summary

```
Slicing (p.1~4)
└─ String slices s[a:b:c]   (p.1~4)
```

## 1. String slices (p.1~4)

The **end index is excluded**.

> **Warning**: Out-of-range slices do not raise an error (p.4).

```out
>>> "abcdef"[1:4]
'bcd'
```

## Review questions

| # | Question | Answer |
|---|---|---|
| 1 | Is the end index included? | No (p.1). |

## Think it through

### Think 1. Reverse a string (p.3)

```
s = "abcdef"
print(s[::-1])
```

**Predict**: What is printed?

[[Predict]]

> **Hint**: A negative step walks backwards.

[[Answer]]
**`fedcba` is printed.**

The step `-1` reads the string from the end to the start.
[[/Answer]]
