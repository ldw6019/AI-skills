# Evaluation scenarios (not yet run)

Written per the "at least three scenarios" advice in Anthropic's skill authoring guide. Each pairs an input with expected behaviors. They have NOT been executed against this skill yet; run each once without the skill (baseline) and once with it, and compare.

## 1. Lecture only

Input: one lecture PDF (text-based, about 30 slides). No practice material, no student questions, no exam info.

Expected:
- Works without asking more than one short question.
- The final report says B, C, D did not exist.
- No `실습 자료 현황` section.
- Every topic heading has `(p.A~B)` and the one-page summary has `(p.N)` on every line.
- Script lint shows no leftover `**` or `[[`.

## 2. Exam scope given

Input: lecture PDF plus the sentence "시험은 41쪽까지만 나와."

Expected:
- A `> **주의**:` box right under the title states the range.
- The part after p.41 is kept, titled `[시험범위 아님]`, with a one-line box at its top.
- No self-test cards for the excluded part.
- The scope is recorded somewhere the next session will see it.

## 3. Open assignment with code

Input: lecture PDF, a lab folder with example code, and an assignment guide whose solution is still open.

Expected:
- Example code is run in a throwaway directory and real output is quoted in `out` blocks.
- Anything that could not be run is marked `(미검증, 직접 실행해 보지 못함)`.
- The assignment is explained, not solved.
- The student's own folders are untouched; temporary files are deleted.
- With `--answers appendix`, no answer text appears inside any card in the PDF.

## 4. Design path (with study-sheet-design)

Input: the same as scenario 2, with `study-sheet-design` installed and a Chromium-family browser available.

Expected:
- `render_study.py STUDY.md --lint-only` runs before any HTML is written.
- The HTML starts from `scaffold.py`, and no `<!-- TODO` comment is left in the final HTML.
- `render.py` prints "차례: 쪽 번호가 실제와 맞다".
- The design path is chosen (SKILL.md 6.0) and the report names it.
- `render.py ... --source STUDY.md` reports the same card count, the same review-question count, no page number or page range missing from `STUDY.md`, and no `pre.out` line that is not in a `STUDY.md` `out` block.
- No page is more than half empty unless it is the last page or the page before an answer appendix, and `render.py` prints no `쪽 끝 제목` (orphaned heading) warning. There is no page-count target: long lecture material gives a long sheet.
- The one-page summary map shows `p.N` labels, and the excluded part has a `시험범위 아님` mark.
- The student's folder ends with `STUDY.md`, the HTML, and the PDF only.

## 5. Design path unavailable

Input: the same as scenario 1, with `study-sheet-design` installed but no Chromium-family browser (`render.py --check` fails).

Expected:
- No question to the student; the Markdown path is used.
- The report says in one line that the design path was skipped and why.

## 6. Exam signals and past exam style

Input: lecture transcript where the lecturer says "이 부분은 시험에 낸다" at p.23, plus D: last year's exam with 단답형 and 출력 예측 questions.

Expected:
- p.23 carries `> **핵심**:` with the source page, and at least one question or card covers it.
- No other topic is labeled as exam-likely in the sheet.
- 복습 질문 uses 단답형 and 출력 예측 forms, the intro says "기출 형식(D)을 따른 자습용 문제", and no past exam question is copied.

## 7. Full run on `tests/e2e`

Input: everything in `tests/e2e/input/` and the request "7주차 공부자료 만들어줘. 시험은 14쪽까지."

Expected: every item in `tests/e2e/README.md` under "Traps the run must catch" and "Expected result". In particular the slide 13 error and the 10/20 answer are corrected with observed output, the open assignment is not solved, and the design-path render prints no warning lines.

## 8. Legibility

Input: any sheet, rendered on either path, with an accent color the student asks for (try a light one such as yellow `#ffd600`).

Expected:
- `scaffold.py` darkens the light accent and says so; nothing is printed white on a light fill or black on a dark fill.
- `render.py` (or `render.py --pdf` for the Markdown path) prints "대비: 모든 글자가 WCAG AA 기준을 넘는다".
